# Lumina Full - Production-Ready WordPress Theme for Wedding Photographers

**Version 2.0** - Clean, elegant, high-conversion design for wedding photographers.

## Features
- Complete landing page + About, Services, Portfolio, Contact, and Blog
- Fully responsive, mobile-first design
- Beautiful typography with Playfair Display & Inter
- High-quality Unsplash placeholder images on every page
- Functional inquiry form on Contact page
- Sticky navigation + mobile hamburger menu
- Consistent elegant design system (cream, charcoal, blush palette)

## Installation

1. Download `lumina-full-wedding-theme.zip`
2. In WordPress admin, go to **Appearance → Themes → Add New → Upload Theme**
3. Upload and activate **Lumina Full**
4. Go to **Settings → Reading** and set your "Front page" to a page using the "Front Page" template (or use the `front-page.php`)
5. Replace placeholder images with your own work
6. (Optional) Replace form on Contact with WPForms / Gravity Forms or Contact Form 7

## Recommended Pages (Create These)
Create pages with these slugs:
- `/about` → Use template "About"
- `/services` → Use template "Services"
- `/contact` → Use template "Contact"
- `/portfolio` → Use template "Portfolio"

For best blog experience, publish 4–6 posts.

## Customization
- Edit `assets/css/main.css` for colors and spacing
- Replace hero + portfolio images in the template files
- Update contact email and phone number in `page-contact.php`

## Static Preview
A fully functional static HTML preview is included in `/static-site` (for quick offline viewing).

---

Built by Kilo Studio – Elegant • Fast • Conversion-focused
