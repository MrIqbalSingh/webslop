<?php get_header(); ?>

<section class="max-w-4xl mx-auto px-8 py-20">
  <h1 class="section-title">Welcome to Lumina</h1>
  <p class="mt-6 text-xl max-w-lg">This is the default index template. For best results, set a static front page to "Front Page" in Settings → Reading.</p>
  <a href="<?php echo home_url('/contact'); ?>" class="mt-8 inline-block elegant-btn border border-[#CDAE90] px-8 py-4 text-sm tracking-widest">INQUIRE NOW</a>
</section>

<?php get_footer(); ?>
