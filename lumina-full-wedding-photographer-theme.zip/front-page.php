<?php get_header(); ?>

<div class="max-w-screen-2xl mx-auto px-8">
  <h1 class="section-title py-12">The Full Experience</h1>
  
  <p class="text-xl max-w-2xl">Welcome to the complete Lumina Wedding Photography theme.</p>
  
  <div class="my-14 grid md:grid-cols-2 gap-8">
    <div class="p-10 bg-white rounded-2xl">
      <strong>Quick Links</strong>
      <ul class="mt-6 space-y-3 text-[#6A7B6F]">
        <li><a href="<?php echo home_url('/about'); ?>">About Luna</a></li>
        <li><a href="<?php echo home_url('/services'); ?>">Services + Pricing</a></li>
        <li><a href="<?php echo home_url('/contact'); ?>">Contact & Booking</a></li>
        <li><a href="<?php echo get_post_type_archive_link('post'); ?>">Journal</a></li>
      </ul>
    </div>
  </div>
</div>

<?php get_footer(); ?>
