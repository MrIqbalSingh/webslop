<footer class="bg-[#1F2429] text-[#F1EDE5] pt-16 pb-10 text-sm">
  <div class="max-w-screen-2xl mx-auto px-8">
    <div class="grid md:grid-cols-2 gap-y-12">
      <div>
        <div class="font-serif text-4xl tracking-tight text-white">lumina</div>
        <p class="max-w-xs mt-3 text-[#BDB4A7]">Documenting love with intention, elegance, and quiet beauty.</p>
      </div>
      
      <div class="grid grid-cols-2 gap-x-8 md:justify-items-end">
        <div>
          <div class="uppercase tracking-[1.5px] text-xs mb-4 text-[#CDAE90]">Studio</div>
          <div>Seattle, WA<br>Available Worldwide</div>
          <div class="mt-4">hello@lumina.studio<br>+1 (206) 555-0148</div>
        </div>
        
        <div>
          <div class="uppercase tracking-[1.5px] text-xs mb-4 text-[#CDAE90]">Connect</div>
          <div class="space-y-1">
            <a href="#" class="block hover:text-[#CDAE90]">Instagram</a>
            <a href="#" class="block hover:text-[#CDAE90]"> Pinterest</a>
            <a href="contact.html" class="block hover:text-[#CDAE90]">Email</a>
          </div>
        </div>
      </div>
    </div>

    <div class="border-t border-white/10 mt-14 pt-8 flex flex-col md:flex-row items-center gap-y-1 justify-between text-xs text-[#7F7668]">
      <div>© <?php echo date('Y'); ?> Lumina Photography. All rights reserved.</div>
      <div>Privacy · Legal</div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
