<?php get_header(); ?>

<div class="max-w-screen-2xl mx-auto px-8 py-12 max-w-4xl">
  <?php while (have_posts()) : the_post(); ?>
    <h1 class="section-title"><?php the_title(); ?></h1>
    <div class="mt-8 text-lg leading-relaxed">
      <?php the_content(); ?>
    </div>
  <?php endwhile; ?>
</div>

<?php get_footer(); ?>
