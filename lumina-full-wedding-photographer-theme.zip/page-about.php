<?php
/* Template Name: About */
get_header();
?>

<div class="max-w-screen-2xl mx-auto px-8 pt-14 pb-20">
  <div class="max-w-4xl">
    <h1 class="heading-display text-[56px] leading-[1.0] tracking-[-2.8px]">I photograph weddings with reverence.</h1>
    <p class="mt-8 text-2xl max-w-[37ch]">For twelve years I’ve documented the honest, the quiet, and the deeply felt.</p>
  </div>
</div>

<div class="max-w-screen-2xl mx-auto px-8 grid md:grid-cols-12 gap-x-8 pb-20">
  <div class="md:col-span-7">
    <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=1400&q=80" class="rounded-3xl w-full" alt="Luna Rivera - Wedding Photographer Portrait">
  </div>
  <div class="md:col-span-5 pt-10 md:pt-8">
    <p class="text-lg leading-relaxed">I don’t chase perfection. I chase feeling. I believe the most important photographs are the ones that transport you back to how the day felt — not just how it looked.</p>
    <p class="mt-5">Based in Seattle with a global passport, I am available for a limited number of weddings each year. I work with couples who value intention over performance and quiet beauty over trends.</p>
    
    <div class="mt-9 flex gap-4 text-xs uppercase tracking-[2px]">
      <div class="px-6 py-2 border border-[#CDAE90]">Seattle • Pacific Northwest</div>
      <div class="px-6 py-2 bg-[#1F2429] text-white">Worldwide Travel</div>
    </div>
  </div>
</div>

<?php get_footer(); ?>
