// Lumina Full - Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
  // Lucide icons
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
  
  // Mobile menu toggle
  const mobileBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  
  if (mobileBtn && mobileMenu) {
    mobileBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  }
  
  // Simple smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
  
  // Portfolio lightbox (simple version)
  const portfolioItems = document.querySelectorAll('.portfolio-item');
  if (portfolioItems.length) {
    portfolioItems.forEach(item => {
      item.addEventListener('click', () => {
        const img = item.querySelector('img');
        if (img) {
          const modal = document.createElement('div');
          modal.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4';
          modal.innerHTML = `
            <div class="relative max-w-5xl w-full">
              <img src="${img.src}" class="w-full rounded-2xl shadow-2xl max-h-[90vh] object-contain" alt="${img.alt}">
              <button class="absolute top-4 right-4 text-white text-3xl leading-none close-lightbox">&times;</button>
            </div>
          `;
          document.body.appendChild(modal);
          
          modal.addEventListener('click', (e) => {
            if (e.target.classList.contains('close-lightbox') || e.target === modal) {
              modal.remove();
            }
          });
        }
      });
    });
  }
});

// Tailwind script for runtime config (if using CDN)
function initTailwind() {
  const style = document.createElement('style');
  style.innerHTML = `
    .section-title { font-size: 2.85rem; line-height: 1.05; letter-spacing: -1.8px; }
  `;
  document.head.appendChild(style);
}
