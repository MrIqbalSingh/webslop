<?php get_header(); ?>

<div class="max-w-screen-2xl mx-auto px-8 pt-14 pb-16">
  <div class="flex justify-between items-center">
    <div>
      <h1 class="section-title">Journal</h1>
      <p class="text-[#6A7B6F]">Stories from behind the lens</p>
    </div>
    <a href="#" class="uppercase tracking-widest text-xs font-medium hidden md:block">Subscribe to Newsletter →</a>
  </div>
</div>

<div class="max-w-screen-2xl mx-auto px-8 pb-20">
  <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-14">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <article class="group">
        <a href="<?php the_permalink(); ?>" class="block overflow-hidden rounded-2xl aspect-[16/10]">
          <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('lumina-portfolio', ['class' => 'w-full h-full object-cover group-hover:scale-110 transition-transform']); ?>
          <?php else : ?>
            <img src="https://images.unsplash.com/photo-1500930284181-5c1a3a9f4af4?w=1200" class="w-full h-full object-cover group-hover:scale-110 transition-transform" alt="<?php the_title(); ?>">
          <?php endif; ?>
        </a>
        
        <div class="pt-7">
          <h2 class="font-medium text-3xl tracking-tight leading-tight"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <div class="text-sm text-[#6A7B6F] mt-4"><?php echo get_the_date('F j, Y'); ?> — <?php the_author(); ?></div>
        </div>
      </article>
    <?php endwhile; else : ?>
      <!-- Demo Blog Posts when no real posts exist -->
      <article class="group">
        <a href="#" class="block rounded-2xl overflow-hidden"><img src="https://images.unsplash.com/photo-1519741497674-611481863552?w=1200" class="w-full hover:scale-[1.04] transition" alt="Journal Post"></a>
        <div class="pt-7">
          <h3 class="font-medium text-[27px] tracking-tight">A Quiet October Wedding in the Gorge</h3>
          <div class="text-sm text-[#6A7B6F] mt-5">Oct 15, 2025 • Luna Rivera</div>
        </div>
      </article>
    <?php endif; ?>
  </div>
</div>

<?php get_footer(); ?>
