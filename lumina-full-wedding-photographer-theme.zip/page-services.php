<?php
/* Template Name: Services */
get_header();
?>

<section class="max-w-screen-2xl mx-auto px-8 py-16">
  <div class="max-w-3xl">
    <h1 class="section-title">Services & Investment</h1>
    <p class="mt-5 text-xl">Thoughtful, experience-led coverage for couples who want to be fully present in their day.</p>
  </div>
</section>

<section class="max-w-screen-2xl mx-auto px-8 pb-20">
  <div class="grid md:grid-cols-3 gap-6">
    
    <!-- Package 1 -->
    <div class="bg-white p-9 rounded-3xl">
      <div class="text-xs uppercase text-[#6A7B6F]">Most Popular</div>
      <h3 class="mt-1 text-[27px] font-medium">Signature Day</h3>
      <div class="text-5xl font-semibold mt-6">$5,800</div>
      <div class="mt-8 space-y-3 text-sm">
        <div>→ 10 hours of coverage</div>
        <div>→ Engagement session (2 hrs)</div>
        <div>→ Hand-edited gallery (300+ images)</div>
        <div>→ Private online gallery + downloads</div>
        <div>→ Client proofing portal</div>
      </div>
      <a href="<?php echo home_url('/contact'); ?>" class="mt-9 block text-center py-3 border border-[#1F2429] elegant-btn">Inquire — Signature Day</a>
    </div>

    <!-- Package 2 -->
    <div class="bg-white p-9 rounded-3xl">
      <h3 class="mt-1 text-[27px] font-medium">Elopement / Intimate</h3>
      <div class="text-5xl font-semibold mt-6">$3,600</div>
      <div class="mt-8 space-y-3 text-sm">
        <div>→ Up to 4 hours coverage</div>
        <div>→ 120+ curated images</div>
        <div>→ Gallery + print credits</div>
      </div>
      <a href="<?php echo home_url('/contact'); ?>" class="mt-9 block text-center py-3 border border-[#1F2429] elegant-btn">Inquire — Intimate</a>
    </div>

    <!-- Package 3 -->
    <div class="bg-white p-9 rounded-3xl">
      <h3 class="mt-1 text-[27px] font-medium">Destination</h3>
      <div class="text-5xl font-semibold mt-6">From $9,400</div>
      <div class="mt-8 space-y-3 text-sm">
        <div>→ 2 full days coverage</div>
        <div>→ 500+ edited images</div>
        <div>→ Premium 30-page album included</div>
        <div>→ Travel & accommodation covered up to $1,250</div>
      </div>
      <a href="<?php echo home_url('/contact'); ?>" class="mt-9 block text-center py-3 border border-[#1F2429] elegant-btn">Inquire — Destination</a>
    </div>

  </div>
</section>

<?php get_footer(); ?>
