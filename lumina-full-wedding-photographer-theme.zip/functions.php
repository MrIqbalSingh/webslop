<?php
/**
 * Lumina Full - Main functions file
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme setup
function lumina_full_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('custom-logo');
    add_image_size('lumina-portfolio', 1200, 800, true);
    add_image_size('lumina-hero', 2000, 1200, true);
}
add_action('after_setup_theme', 'lumina_full_setup');

// Enqueue assets
function lumina_full_assets() {
    // Tailwind via CDN for immediate beauty (production: replace with compiled CSS if needed)
    wp_enqueue_style('tailwind', 'https://cdn.tailwindcss.com', array(), '3.4');
    
    // Custom styles (inlined for simplicity in this package)
    wp_enqueue_style('lumina-main', get_template_directory_uri() . '/assets/css/main.css', array(), '2.0.0');

    wp_enqueue_script('lucide', 'https://unpkg.com/lucide@latest', array(), '1.0', true);
    wp_enqueue_script('lumina-main', get_template_directory_uri() . '/assets/js/main.js', array('lucide'), '2.0', true);
}
add_action('wp_enqueue_scripts', 'lumina_full_assets');

// Add custom Tailwind script inline
function lumina_full_tailwind_script() {
    // Tailwind script is included via CDN in templates for instant preview
}
add_action('wp_head', 'lumina_full_tailwind_script');
