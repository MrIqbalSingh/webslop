<?php
/* 
Template Name: Portfolio
*/
get_header();
?>

<section class="max-w-screen-2xl mx-auto px-8 pt-16 pb-12">
  <div class="mb-10">
    <div class="uppercase tracking-[3px] text-xs text-[#CDAE90]">THE WORK</div>
    <h1 class="section-title">Every Gallery Tells a Story</h1>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php 
    $galleries = [
      ['title' => 'Sylvie & Alexander', 'location' => 'Columbia Gorge', 'date' => 'October 2025', 'img' => 'https://images.unsplash.com/photo-1519741497674-611481863552?w=1200'],
      ['title' => 'Emma & Theo', 'location' => 'Oregon Coast', 'date' => 'August 2025', 'img' => 'https://images.unsplash.com/photo-1500930284181-5c1a3a9f4af4?w=1200'],
      ['title' => 'Isla & Leo', 'location' => 'Woodinville Wine Country', 'date' => 'June 2025', 'img' => 'https://images.unsplash.com/photo-1559333086-b0a7f7f3f8e9?w=1200'],
      ['title' => 'Priya & Michael', 'location' => 'Seattle', 'date' => 'September 2024', 'img' => 'https://images.unsplash.com/photo-1522673607200-8b3b8d8e7b9a?w=1200'],
    ];
    
    foreach ($galleries as $g): ?>
      <div class="portfolio-item">
        <div class="overflow-hidden rounded-2xl aspect-[16/11]">
          <img src="<?php echo $g['img']; ?>" class="w-full h-full object-cover hover:scale-105 transition" alt="<?php echo $g['title']; ?>">
        </div>
        <div class="mt-6">
          <div class="flex justify-between">
            <div class="font-medium text-2xl tracking-tight"><?php echo $g['title']; ?></div>
          </div>
          <div class="text-[#6A7B6F] mt-1 text-sm"><?php echo $g['location']; ?> • <?php echo $g['date']; ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?php get_footer(); ?>
