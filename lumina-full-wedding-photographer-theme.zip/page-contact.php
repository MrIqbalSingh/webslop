<?php
/* Template Name: Contact */
get_header();
?>

<div class="max-w-screen-2xl mx-auto px-8 pt-14 pb-20">
  <div class="max-w-2xl">
    <h1 class="section-title text-[56px]">Let’s begin your story.</h1>
    <p class="mt-4 text-xl">Tell me about your day and I’ll reply within 24 hours.</p>
  </div>
</div>

<div class="max-w-screen-2xl mx-auto px-8 pb-24">
  <div class="grid md:grid-cols-12 gap-x-16">

    <!-- Form -->
    <div class="md:col-span-7">
      <form id="booking" method="post" class="space-y-6" action="#">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="text-xs tracking-widest text-[#6A7B6F]">FULL NAME</label>
            <input type="text" name="name" required class="w-full mt-1.5 p-4 border border-[#D8D1C5] bg-white">
          </div>
          <div>
            <label class="text-xs tracking-widest text-[#6A7B6F]">EMAIL ADDRESS</label>
            <input type="email" name="email" required class="w-full mt-1.5 p-4 border border-[#D8D1C5] bg-white">
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="text-xs tracking-widest text-[#6A7B6F]">WEDDING DATE</label>
            <input type="date" name="date" required class="w-full mt-1.5 p-4 border border-[#D8D1C5] bg-white">
          </div>
          <div>
            <label class="text-xs tracking-widest text-[#6A7B6F]">ESTIMATED GUEST COUNT</label>
            <input type="text" name="guests" placeholder="e.g. 85" class="w-full mt-1.5 p-4 border border-[#D8D1C5] bg-white">
          </div>
        </div>

        <div>
          <label class="text-xs tracking-widest text-[#6A7B6F]">VENUE / LOCATION IDEAS</label>
          <input type="text" name="venue" class="w-full mt-1.5 p-4 border border-[#D8D1C5] bg-white">
        </div>

        <div>
          <label class="text-xs tracking-widest text-[#6A7B6F]">TELL ME ABOUT YOUR VISION</label>
          <textarea name="message" rows="6" placeholder="We're dreaming of..." class="w-full mt-1.5 p-4 border border-[#D8D1C5] bg-white resize-y"></textarea>
        </div>

        <button type="submit" class="elegant-btn mt-4 w-full md:w-auto px-14 py-[17px] bg-[#CDAE90] text-[#1F2429] text-sm tracking-[1.2px] font-medium">
          SEND INQUIRY
        </button>
      </form>
    </div>

    <!-- Contact Info -->
    <div class="md:col-span-5 mt-14 md:mt-0 bg-white p-9 rounded-3xl">
      <div class="text-sm space-y-7">
        <div>
          <div class="uppercase text-xs tracking-[2px] text-[#6A7B6F]">STUDIO</div>
          <div class="mt-1 text-lg">Seattle, Washington</div>
        </div>
        
        <div>
          <div class="uppercase text-xs tracking-[2px] text-[#6A7B6F]">PHONE</div>
          <a href="tel:+12065550148" class="block mt-1 text-xl font-medium">(206) 555-0148</a>
        </div>

        <div>
          <div class="uppercase text-xs tracking-[2px] text-[#6A7B6F]">EMAIL</div>
          <a href="mailto:hello@lumina.studio" class="block mt-1 text-xl font-medium">hello@lumina.studio</a>
        </div>
      </div>

      <div class="mt-12 pt-8 border-t text-xs text-[#6A7B6F]">
        Most inquiries receive a reply within 24 hours.<br>
        You will also receive our full investment guide upon inquiry.
      </div>
    </div>
  </div>
</div>

<?php get_footer(); ?>
