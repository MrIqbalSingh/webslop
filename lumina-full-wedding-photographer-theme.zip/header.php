<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class('bg-[#F8F5F1] text-[#1F2429]'); ?>>

<nav class="bg-white border-b border-[#EDEAE4] sticky top-0 z-50">
  <div class="max-w-screen-2xl mx-auto px-8">
    <div class="flex justify-between items-center h-20">
      
      <a href="<?php echo home_url(); ?>" class="flex items-center gap-x-4">
        <div class="w-9 h-9 bg-[#1F2429] flex items-center justify-center text-white font-semibold text-2xl tracking-[-1.5px]">L</div>
        <div>
          <div class="font-serif text-3xl tracking-tight">lumina</div>
          <div class="text-[9px] text-[#6A7B6F] -mt-1.5 tracking-[1.5px]">WEDDING PHOTOGRAPHY</div>
        </div>
      </a>

      <!-- Desktop Nav -->
      <div class="hidden md:flex items-center gap-x-9 text-sm font-medium tracking-[0.5px] uppercase">
        <a href="<?php echo home_url(); ?>" class="nav-link <?php echo is_front_page() ? 'nav-active' : ''; ?>">Work</a>
        <a href="<?php echo home_url('/about'); ?>" class="nav-link <?php echo is_page('about') ? 'nav-active' : ''; ?>">About</a>
        <a href="<?php echo home_url('/services'); ?>" class="nav-link <?php echo is_page('services') ? 'nav-active' : ''; ?>">Services</a>
        <a href="<?php echo get_post_type_archive_link('post'); ?>" class="nav-link">Journal</a>
        <a href="<?php echo home_url('/contact'); ?>" class="nav-link <?php echo is_page('contact') ? 'nav-active' : ''; ?>">Contact</a>
      </div>

      <div class="flex items-center gap-x-3">
        <a href="<?php echo home_url('/contact#booking'); ?>" 
           class="hidden md:inline-block elegant-btn px-7 py-[13px] text-xs font-medium tracking-[1px] border border-[#CDAE90] hover:bg-[#CDAE90] hover:text-white transition-all">
          BOOK YOUR DATE
        </a>
        
        <!-- Mobile Menu Button -->
        <button id="mobile-menu-btn" class="md:hidden p-3">
          <i data-lucide="menu" class="w-5 h-5"></i>
        </button>
      </div>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="hidden md:hidden border-t py-6 text-sm uppercase tracking-widest">
      <a href="<?php echo home_url(); ?>" class="block py-3">Work</a>
      <a href="<?php echo home_url('/about'); ?>" class="block py-3">About</a>
      <a href="<?php echo home_url('/services'); ?>" class="block py-3">Services</a>
      <a href="<?php echo get_post_type_archive_link('post'); ?>" class="block py-3">Journal</a>
      <a href="<?php echo home_url('/contact'); ?>" class="block py-3">Contact</a>
      <div class="pt-4">
        <a href="<?php echo home_url('/contact#booking'); ?>" class="elegant-btn block text-center py-3 border border-[#CDAE90]">BOOK NOW</a>
      </div>
    </div>
  </div>
</nav>
