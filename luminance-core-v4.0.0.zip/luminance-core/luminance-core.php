<?php
/**
 * Plugin Name:       Luminance Core
 * Plugin URI:        https://luminance-studio.example
 * Description:       Core functionality for the Luminance Studio photography site: registers the Portfolio custom post type and taxonomy, seeds and maintains demo content, and provides theme-independent data so the site survives theme changes. Presentation lives in the theme; this plugin owns functionality.
 * Version:           4.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Luminance Studio
 * Author URI:        https://luminance-studio.example
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       luminance-core
 * Domain Path:       /languages
 *
 * @package Luminance\Core
 */

// Prevent direct access — every PHP entry point must guard ABSPATH (WPCS).
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * --------------------------------------------------------------------------
 * Constants
 * --------------------------------------------------------------------------
 * Versioned and path constants keep includes and cache-busting consistent and
 * make the plugin relocatable. All public symbols are prefixed `LUMINANCE_` /
 * `luminance_` to avoid collisions, per the WordPress PHP Coding Standards.
 */
define( 'LUMINANCE_CORE_VERSION', '4.0.0' );
define( 'LUMINANCE_CORE_FILE', __FILE__ );
define( 'LUMINANCE_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'LUMINANCE_CORE_URL', plugin_dir_url( __FILE__ ) );
define( 'LUMINANCE_CORE_INC', LUMINANCE_CORE_PATH . 'includes/' );

/*
 * --------------------------------------------------------------------------
 * Autoloading
 * --------------------------------------------------------------------------
 * A small autoloader maps Luminance_* classes to their files, so new classes
 * drop in without editing this bootstrap. The autoloader itself is the only
 * explicit require.
 */
require_once LUMINANCE_CORE_INC . 'class-luminance-autoloader.php';
Luminance_Autoloader::register();

/*
 * --------------------------------------------------------------------------
 * Activation / deactivation
 * --------------------------------------------------------------------------
 * Registering the CPT then flushing rewrite rules on (de)activation is the
 * documented, performant pattern: flush once on activation rather than on
 * every request.
 */
register_activation_hook( __FILE__, array( 'Luminance_Core', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Luminance_Core', 'deactivate' ) );

/*
 * --------------------------------------------------------------------------
 * Bootstrap
 * --------------------------------------------------------------------------
 * Initialise inside a guard. A fatal in any single subsystem should never take
 * the whole site down with a white screen; instead we log it (visible with
 * WP_DEBUG_LOG enabled) and let the rest of WordPress continue. An admin notice
 * surfaces the problem in wp-admin without exposing details to visitors.
 */
try {
	Luminance_Core::init();
} catch ( \Throwable $e ) {
	if ( function_exists( 'error_log' ) ) {
		error_log( 'Luminance Core init error: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine() );
	}
	add_action(
		'admin_notices',
		static function () use ( $e ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}
			echo '<div class="notice notice-error"><p>'
				. esc_html__( 'Luminance Core hit an error while starting:', 'luminance-core' ) . ' '
				. esc_html( $e->getMessage() )
				. '</p></div>';
		}
	);
}
