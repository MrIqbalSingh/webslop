<?php
/**
 * Portfolio demo-content seeder: collections, image attachments, and galleries.
 *
 * Runs once on a fresh install. Every step checks for existing data first, so
 * on a site that already has portfolio content (e.g. migrated from the previous
 * setup) it adopts what is there and adds nothing — making it safe for cutover.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Portfolio_Seeder
 */
final class Luminance_Portfolio_Seeder {

	const DONE_OPTION = 'luminance_portfolio_seeded';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'maybe_seed' ), 98 );
	}

	/**
	 * Seed portfolio content once, only if none exists yet.
	 *
	 * @return void
	 */
	public static function maybe_seed() {
		if ( '1' === get_option( self::DONE_OPTION ) ) {
			return;
		}
		if ( ! post_type_exists( Luminance_Portfolio::POST_TYPE ) ) {
			return;
		}

		// If galleries already exist (migrated site), adopt them: mark done.
		$existing = get_posts(
			array(
				'post_type'      => Luminance_Portfolio::POST_TYPE,
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'post_status'    => 'any',
			)
		);
		if ( ! empty( $existing ) ) {
			update_option( self::DONE_OPTION, '1' );
			return;
		}

		$terms   = self::seed_collections();
		$att_ids = self::seed_attachments();
		self::seed_galleries( $terms, $att_ids );

		update_option( self::DONE_OPTION, '1' );
	}

	/**
	 * Create the collection terms.
	 *
	 * @return array Map of slug => term ID.
	 */
	private static function seed_collections() {
		$collections = array(
			'weddings'     => __( 'Weddings', 'luminance-core' ),
			'engagements'  => __( 'Engagements', 'luminance-core' ),
			'events-galas' => __( 'Events & Galas', 'luminance-core' ),
			'details'      => __( 'Details', 'luminance-core' ),
		);
		$ids = array();
		foreach ( $collections as $slug => $name ) {
			$existing = get_term_by( 'slug', $slug, Luminance_Portfolio::TAXONOMY );
			if ( $existing ) {
				$ids[ $slug ] = (int) $existing->term_id;
				continue;
			}
			$term = wp_insert_term( $name, Luminance_Portfolio::TAXONOMY, array( 'slug' => $slug ) );
			if ( ! is_wp_error( $term ) ) {
				$ids[ $slug ] = (int) $term['term_id'];
			}
		}
		return $ids;
	}

	/**
	 * Register attachment records for the bundled image files.
	 *
	 * @return array Map of key => attachment ID.
	 */
	private static function seed_attachments() {
		$images = array(
			'hero'    => array( 'hero-ceremony.jpg', __( 'Ceremony Arch at Golden Hour', 'luminance-core' ) ),
			'couple'  => array( 'portfolio-couple-golden.jpg', __( 'Golden Hour Embrace', 'luminance-core' ) ),
			'rings'   => array( 'portfolio-rings-detail.jpg', __( 'The Rings', 'luminance-core' ) ),
			'table'   => array( 'portfolio-reception-table.jpg', __( 'Reception Tablescape', 'luminance-core' ) ),
			'dance'   => array( 'portfolio-first-dance.jpg', __( 'The First Dance', 'luminance-core' ) ),
			'venue'   => array( 'portfolio-venue-interior.jpg', __( 'Venue Interior', 'luminance-core' ) ),
			'bouquet' => array( 'portfolio-bouquet.jpg', __( 'The Bouquet', 'luminance-core' ) ),
			'event'   => array( 'portfolio-gala-event.jpg', __( 'Gala Evening', 'luminance-core' ) ),
			'about'   => array( 'about-portrait.jpg', __( 'Studio Portrait', 'luminance-core' ) ),
		);

		$upload_dir = wp_upload_dir();
		$base_url   = content_url( '/uploads/portfolio' );
		$ids        = array();

		foreach ( $images as $key => $info ) {
			list( $file, $title ) = $info;
			$relative = 'portfolio/' . $file;
			$fullpath = trailingslashit( $upload_dir['basedir'] ) . $relative;

			$found = get_posts(
				array(
					'post_type'   => 'attachment',
					'meta_key'    => '_wp_attached_file', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value'  => $relative,           // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
					'numberposts' => 1,
					'fields'      => 'ids',
				)
			);
			if ( $found ) {
				$ids[ $key ] = (int) $found[0];
				continue;
			}

			$att_id = wp_insert_attachment(
				array(
					'post_mime_type' => 'image/jpeg',
					'post_title'     => $title,
					'post_status'    => 'inherit',
					'guid'           => $base_url . '/' . $file,
				),
				$fullpath
			);

			if ( ! is_wp_error( $att_id ) ) {
				update_post_meta( $att_id, '_wp_attached_file', $relative );
				if ( file_exists( $fullpath ) ) {
					require_once ABSPATH . 'wp-admin/includes/image.php';
					$meta = wp_generate_attachment_metadata( $att_id, $fullpath );
					wp_update_attachment_metadata( $att_id, $meta );
				}
				$ids[ $key ] = (int) $att_id;
			}
		}
		return $ids;
	}

	/**
	 * Create the gallery posts and assign collections + cover images.
	 *
	 * @param array $terms   Map of collection slug => term ID.
	 * @param array $att_ids Map of image key => attachment ID.
	 * @return void
	 */
	private static function seed_galleries( $terms, $att_ids ) {
		$galleries = array(
			array( __( 'Amelia & Theo — A Riverside Wedding', 'luminance-core' ), 'amelia-theo', 'couple', 'weddings', 1 ),
			array( __( 'The First Dance', 'luminance-core' ), 'first-dance', 'dance', 'weddings', 2 ),
			array( __( 'Rings & Quiet Details', 'luminance-core' ), 'rings-details', 'rings', 'details', 3 ),
			array( __( 'A Candlelit Reception', 'luminance-core' ), 'candlelit-reception', 'table', 'weddings', 4 ),
			array( __( 'Autumn Gala — The Foundation Evening', 'luminance-core' ), 'autumn-gala', 'event', 'events-galas', 5 ),
			array( __( 'Golden Hour Engagement', 'luminance-core' ), 'golden-engagement', 'couple', 'engagements', 6 ),
			array( __( 'The Grand Venue', 'luminance-core' ), 'grand-venue', 'venue', 'events-galas', 7 ),
			array( __( 'Blooms & Bouquets', 'luminance-core' ), 'blooms-bouquets', 'bouquet', 'details', 8 ),
		);

		foreach ( $galleries as $g ) {
			list( $title, $slug, $imgkey, $collslug, $order ) = $g;
			if ( get_page_by_path( $slug, OBJECT, Luminance_Portfolio::POST_TYPE ) ) {
				continue;
			}

			$content = '<p>' . esc_html__( 'A selection from this collection, photographed as the day unfolded.', 'luminance-core' ) . '</p>';

			$pid = wp_insert_post(
				array(
					'post_title'   => $title,
					'post_name'    => $slug,
					'post_content' => $content,
					'post_status'  => 'publish',
					'post_type'    => Luminance_Portfolio::POST_TYPE,
					'menu_order'   => $order,
				)
			);

			if ( $pid && ! is_wp_error( $pid ) ) {
				if ( $imgkey && isset( $att_ids[ $imgkey ] ) ) {
					set_post_thumbnail( $pid, $att_ids[ $imgkey ] );
				}
				if ( isset( $terms[ $collslug ] ) ) {
					wp_set_object_terms( $pid, array( (int) $terms[ $collslug ] ), Luminance_Portfolio::TAXONOMY );
				}
			}
		}
	}
}
