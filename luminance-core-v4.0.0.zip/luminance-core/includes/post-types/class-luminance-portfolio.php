<?php
/**
 * Portfolio custom post type and its collection taxonomy.
 *
 * Registering content as a CPT in a plugin (not the theme) means the galleries
 * persist if the theme is ever switched — the documented best practice for
 * "content vs presentation" separation.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Portfolio
 */
final class Luminance_Portfolio {

	const POST_TYPE = 'portfolio';
	const TAXONOMY  = 'portfolio_category';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ), 5 );
		add_action( 'init', array( __CLASS__, 'register_post_type' ), 5 );
	}

	/**
	 * Register the Portfolio post type.
	 *
	 * `show_in_rest` enables the block editor and a REST endpoint, which keeps
	 * the data accessible to future tooling (scalability). Capabilities map to
	 * the standard post caps so role management behaves predictably (security).
	 *
	 * @return void
	 */
	public static function register_post_type() {
		$labels = array(
			'name'                  => _x( 'Portfolio', 'Post type general name', 'luminance-core' ),
			'singular_name'         => _x( 'Gallery', 'Post type singular name', 'luminance-core' ),
			'menu_name'             => _x( 'Portfolio', 'Admin Menu text', 'luminance-core' ),
			'name_admin_bar'        => _x( 'Gallery', 'Add New on Toolbar', 'luminance-core' ),
			'add_new'               => __( 'Add New', 'luminance-core' ),
			'add_new_item'          => __( 'Add New Gallery', 'luminance-core' ),
			'new_item'              => __( 'New Gallery', 'luminance-core' ),
			'edit_item'             => __( 'Edit Gallery', 'luminance-core' ),
			'view_item'             => __( 'View Gallery', 'luminance-core' ),
			'all_items'             => __( 'All Galleries', 'luminance-core' ),
			'search_items'          => __( 'Search Galleries', 'luminance-core' ),
			'not_found'             => __( 'No galleries found.', 'luminance-core' ),
			'not_found_in_trash'    => __( 'No galleries found in Trash.', 'luminance-core' ),
			'featured_image'        => __( 'Cover image', 'luminance-core' ),
			'set_featured_image'    => __( 'Set cover image', 'luminance-core' ),
			'remove_featured_image' => __( 'Remove cover image', 'luminance-core' ),
			'use_featured_image'    => __( 'Use as cover image', 'luminance-core' ),
			'archives'              => __( 'Portfolio archives', 'luminance-core' ),
			'item_published'        => __( 'Gallery published.', 'luminance-core' ),
			'item_updated'          => __( 'Gallery updated.', 'luminance-core' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'has_archive'        => true,
			'show_in_rest'       => true,
			'menu_icon'          => 'dashicons-camera',
			'menu_position'      => 5,
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
			'rewrite'            => array(
				'slug'       => 'portfolio',
				'with_front' => false,
			),
			'capability_type'    => 'post',
			'map_meta_cap'       => true,
			'publicly_queryable' => true,
			'hierarchical'       => false,
		);

		register_post_type( self::POST_TYPE, $args );
	}

	/**
	 * Register the Collection taxonomy (hierarchical, like categories).
	 *
	 * @return void
	 */
	public static function register_taxonomy() {
		$labels = array(
			'name'              => _x( 'Collections', 'taxonomy general name', 'luminance-core' ),
			'singular_name'     => _x( 'Collection', 'taxonomy singular name', 'luminance-core' ),
			'search_items'      => __( 'Search Collections', 'luminance-core' ),
			'all_items'         => __( 'All Collections', 'luminance-core' ),
			'parent_item'       => __( 'Parent Collection', 'luminance-core' ),
			'parent_item_colon' => __( 'Parent Collection:', 'luminance-core' ),
			'edit_item'         => __( 'Edit Collection', 'luminance-core' ),
			'update_item'       => __( 'Update Collection', 'luminance-core' ),
			'add_new_item'      => __( 'Add New Collection', 'luminance-core' ),
			'new_item_name'     => __( 'New Collection Name', 'luminance-core' ),
			'menu_name'         => __( 'Collections', 'luminance-core' ),
		);

		$args = array(
			'labels'            => $labels,
			'hierarchical'      => true,
			'public'            => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array(
				'slug'       => 'collection',
				'with_front' => false,
			),
		);

		register_taxonomy( self::TAXONOMY, array( self::POST_TYPE ), $args );
	}
}
