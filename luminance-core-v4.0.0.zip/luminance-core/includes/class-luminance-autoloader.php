<?php
/**
 * Class autoloader.
 *
 * Maps `Luminance_*` class names to their files under includes/, so new classes
 * can be added without editing the bootstrap. Files follow the WordPress naming
 * convention `class-{lowercased-hyphenated-name}.php`. A small directory map
 * covers the subfolders (post-types, content, admin).
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Autoloader
 */
final class Luminance_Autoloader {

	/**
	 * Register the autoloader.
	 *
	 * @return void
	 */
	public static function register() {
		spl_autoload_register( array( __CLASS__, 'autoload' ) );
	}

	/**
	 * Resolve and load a Luminance_* class file.
	 *
	 * @param string $class The fully-qualified class name requested.
	 * @return void
	 */
	public static function autoload( $class ) {
		if ( 0 !== strpos( $class, 'Luminance_' ) ) {
			return;
		}

		// Luminance_Portfolio_Seeder -> class-luminance-portfolio-seeder.php
		$file = 'class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';

		// Search the known include subdirectories.
		$dirs = array(
			LUMINANCE_CORE_INC,
			LUMINANCE_CORE_INC . 'post-types/',
			LUMINANCE_CORE_INC . 'content/',
			LUMINANCE_CORE_INC . 'admin/',
		);

		foreach ( $dirs as $dir ) {
			$path = $dir . $file;
			if ( is_readable( $path ) ) {
				require_once $path;
				return;
			}
		}
	}
}
