<?php
/**
 * Core orchestrator.
 *
 * Wires up the plugin's subsystems and owns the activation/deactivation
 * lifecycle. Each subsystem is a small, single-responsibility class.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Core
 */
final class Luminance_Core {

	/**
	 * Bootstrap all subsystems. Called once from the plugin bootstrap file.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'load_textdomain' ) );

		// Subsystems. Each registers its own hooks. Guard each independently so
		// a failure in one cannot prevent the others (or blank the site).
		$subsystems = array(
			'Luminance_Portfolio',
			'Luminance_Portfolio_Seeder',
			'Luminance_Content',
			'Luminance_Menus',
			'Luminance_Contact_Form',
			'Luminance_Scalability',
			'Luminance_Maintenance',
			'Luminance_Security',
		);
		foreach ( $subsystems as $class ) {
			if ( class_exists( $class ) && method_exists( $class, 'init' ) ) {
				try {
					call_user_func( array( $class, 'init' ) );
				} catch ( \Throwable $e ) {
					if ( function_exists( 'error_log' ) ) {
						error_log( 'Luminance Core: ' . $class . '::init failed — ' . $e->getMessage() );
					}
				}
			}
		}
	}

	/**
	 * Load translations. Functionality strings live with the plugin.
	 *
	 * @return void
	 */
	public static function load_textdomain() {
		load_plugin_textdomain(
			'luminance-core',
			false,
			dirname( plugin_basename( LUMINANCE_CORE_FILE ) ) . '/languages'
		);
	}

	/**
	 * Activation: register the CPT/taxonomy, then flush rewrite rules once so
	 * the /portfolio/ permalinks resolve without flushing on every request.
	 *
	 * @return void
	 */
	public static function activate() {
		Luminance_Portfolio::register_post_type();
		Luminance_Portfolio::register_taxonomy();
		flush_rewrite_rules();
	}

	/**
	 * Deactivation: flush rewrite rules so the CPT routes are cleaned up.
	 *
	 * @return void
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}
}
