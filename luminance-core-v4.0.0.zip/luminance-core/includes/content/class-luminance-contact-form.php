<?php
/**
 * Built-in contact form shortcode: [luminance_contact].
 *
 * Lives in the plugin (not the theme) so the form survives a theme switch.
 * Security: nonce verification, honeypot, full input sanitisation, and escaped
 * output. Sends via wp_mail() to the site admin address.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Contact_Form
 */
final class Luminance_Contact_Form {

	/**
	 * Register the shortcode.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( 'luminance_contact', array( __CLASS__, 'render' ) );
	}

	/**
	 * Handle submission (if any) and render the form.
	 *
	 * @return string
	 */
	public static function render() {
		$status = self::maybe_handle_submission();

		ob_start();
		?>
		<form class="lum-contact-form" method="post" action="">
			<?php echo wp_kses_post( $status ); ?>
			<div class="lum-field-row">
				<label class="lum-field">
					<span><?php esc_html_e( 'Your name', 'luminance-core' ); ?></span>
					<input type="text" name="lum_name" autocomplete="name" required>
				</label>
				<label class="lum-field">
					<span><?php esc_html_e( 'Email address', 'luminance-core' ); ?></span>
					<input type="email" name="lum_email" autocomplete="email" required>
				</label>
			</div>
			<div class="lum-field-row">
				<label class="lum-field">
					<span><?php esc_html_e( 'Event date', 'luminance-core' ); ?></span>
					<input type="date" name="lum_date">
				</label>
				<label class="lum-field">
					<span><?php esc_html_e( 'Event type', 'luminance-core' ); ?></span>
					<select name="lum_type">
						<option value="Wedding"><?php esc_html_e( 'Wedding', 'luminance-core' ); ?></option>
						<option value="Engagement"><?php esc_html_e( 'Engagement', 'luminance-core' ); ?></option>
						<option value="Corporate / Gala"><?php esc_html_e( 'Corporate / Gala', 'luminance-core' ); ?></option>
						<option value="Celebration"><?php esc_html_e( 'Celebration', 'luminance-core' ); ?></option>
						<option value="Other"><?php esc_html_e( 'Other', 'luminance-core' ); ?></option>
					</select>
				</label>
			</div>
			<label class="lum-field">
				<span><?php esc_html_e( 'Tell me about your day', 'luminance-core' ); ?></span>
				<textarea name="lum_message" rows="5" required></textarea>
			</label>
			<input type="text" name="lum_website" class="lum-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
			<?php wp_nonce_field( 'luminance_contact', 'luminance_contact_nonce' ); ?>
			<button type="submit" class="lum-btn"><?php esc_html_e( 'Send enquiry', 'luminance-core' ); ?></button>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Process a POSTed submission. Returns an escaped status message, or ''.
	 *
	 * @return string
	 */
	private static function maybe_handle_submission() {
		if ( ! isset( $_POST['luminance_contact_nonce'] ) ) {
			return '';
		}
		$nonce = sanitize_text_field( wp_unslash( $_POST['luminance_contact_nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'luminance_contact' ) ) {
			return '';
		}

		// Honeypot: legitimate users leave this empty.
		if ( ! empty( $_POST['lum_website'] ) ) {
			return '';
		}

		$name    = isset( $_POST['lum_name'] ) ? sanitize_text_field( wp_unslash( $_POST['lum_name'] ) ) : '';
		$email   = isset( $_POST['lum_email'] ) ? sanitize_email( wp_unslash( $_POST['lum_email'] ) ) : '';
		$date    = isset( $_POST['lum_date'] ) ? sanitize_text_field( wp_unslash( $_POST['lum_date'] ) ) : '';
		$type    = isset( $_POST['lum_type'] ) ? sanitize_text_field( wp_unslash( $_POST['lum_type'] ) ) : '';
		$message = isset( $_POST['lum_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['lum_message'] ) ) : '';

		if ( ! $name || ! is_email( $email ) || ! $message ) {
			return '<p class="lum-form-error" role="alert">'
				. esc_html__( 'Please complete the name, a valid email, and a message.', 'luminance-core' )
				. '</p>';
		}

		$to      = get_option( 'admin_email' );
		$subject = sprintf(
			/* translators: 1: site name, 2: sender name. */
			__( '[%1$s] New enquiry from %2$s', 'luminance-core' ),
			get_bloginfo( 'name' ),
			$name
		);
		$body = sprintf(
			"Name: %1\$s\nEmail: %2\$s\nEvent date: %3\$s\nEvent type: %4\$s\n\nMessage:\n%5\$s\n",
			$name,
			$email,
			$date,
			$type,
			$message
		);
		$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

		wp_mail( $to, $subject, $body, $headers );

		return '<p class="lum-form-success" role="status">'
			. esc_html__( 'Thank you — your enquiry has been sent. I usually reply within 24 hours.', 'luminance-core' )
			. '</p>';
	}
}
