<?php
/**
 * Content seeding: pages, portfolio galleries, collections, and journal posts.
 *
 * All seeding is idempotent and guarded, using direct DB existence checks
 * (not cached helpers) so a re-run can never create duplicates.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Content
 */
final class Luminance_Content {

	const VERSION_OPTION = 'luminance_content_version';
	const VERSION        = '2.0.0';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'maybe_seed' ), 99 );
		add_action( 'init', array( __CLASS__, 'refresh_about' ), 102 );
		add_action( 'init', array( __CLASS__, 'seed_journal' ), 103 );
	}

	/**
	 * Seed core pages and reading settings once.
	 *
	 * @return void
	 */
	public static function maybe_seed() {
		if ( get_option( self::VERSION_OPTION ) === self::VERSION ) {
			return;
		}

		$pages = array(
			'home'    => array( __( 'Home', 'luminance-core' ), '<p>' . esc_html__( 'Welcome to Luminance.', 'luminance-core' ) . '</p>' ),
			'about'   => array( __( 'About', 'luminance-core' ), self::about_body() ),
			'contact' => array( __( 'Contact', 'luminance-core' ), self::contact_body() ),
			'journal' => array( __( 'Journal', 'luminance-core' ), '<p>' . esc_html__( 'Notes on photography, places and process.', 'luminance-core' ) . '</p>' ),
		);

		$ids = array();
		foreach ( $pages as $slug => $data ) {
			$existing = get_page_by_path( $slug );
			if ( $existing ) {
				$ids[ $slug ] = (int) $existing->ID;
				continue;
			}
			$pid = wp_insert_post(
				array(
					'post_title'   => $data[0],
					'post_name'    => $slug,
					'post_content' => $data[1],
					'post_status'  => 'publish',
					'post_type'    => 'page',
				)
			);
			if ( $pid && ! is_wp_error( $pid ) ) {
				$ids[ $slug ] = (int) $pid;
			}
		}

		if ( isset( $ids['home'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $ids['home'] );
		}
		if ( isset( $ids['journal'] ) ) {
			update_option( 'page_for_posts', $ids['journal'] );
		}
		update_option( 'posts_per_page', 9 );

		update_option( self::VERSION_OPTION, self::VERSION );
	}

	/**
	 * Refresh the About page content once (won't overwrite later manual edits).
	 *
	 * @return void
	 */
	public static function refresh_about() {
		if ( '2' === get_option( 'luminance_about_version' ) ) {
			return;
		}
		$about = get_page_by_path( 'about' );
		if ( $about ) {
			wp_update_post(
				array(
					'ID'           => $about->ID,
					'post_content' => self::about_body(),
				)
			);
		}
		update_option( 'luminance_about_version', '2' );
	}

	/**
	 * Seed journal posts once, with direct-DB duplicate guards.
	 *
	 * @return void
	 */
	public static function seed_journal() {
		global $wpdb;

		if ( '1' === get_option( 'luminance_journal_version' ) ) {
			return;
		}

		foreach ( self::journal_posts() as $slug => $data ) {
			list( $title, $html ) = $data;

			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts}
					 WHERE post_type = 'post'
					   AND post_status NOT IN ( 'trash', 'auto-draft' )
					   AND ( post_name = %s OR post_name REGEXP %s OR post_title = %s )
					 LIMIT 1",
					$slug,
					'^' . $slug . '(-[0-9]+)?$',
					$title
				)
			);
			if ( $exists ) {
				continue;
			}

			wp_insert_post(
				array(
					'post_title'   => $title,
					'post_name'    => $slug,
					'post_content' => $html,
					'post_status'  => 'publish',
					'post_type'    => 'post',
				)
			);
		}

		update_option( 'luminance_journal_version', '1' );
	}

	/**
	 * Journal post definitions: slug => [ title, html ].
	 *
	 * @return array
	 */
	public static function journal_posts() {
		return array(
			'learning-to-see-light'    => array(
				__( 'Learning to see light before you learn the camera', 'luminance-core' ),
				'<p>' . esc_html__( 'Almost everything I know about photography started with paying attention to light long before I understood a single camera setting. A camera only records light; it cannot invent it.', 'luminance-core' ) . '</p>',
			),
			'composition-quiet-rules'  => array(
				__( 'A few quiet rules of composition (and when to break them)', 'luminance-core' ),
				'<p>' . esc_html__( 'Composition is just the arrangement of things inside the frame, and a handful of old ideas genuinely help — as long as you hold them loosely.', 'luminance-core' ) . '</p>',
			),
			'documentary-vs-posed'     => array(
				__( 'Documentary or posed? Why I mostly choose to wait', 'luminance-core' ),
				'<p>' . esc_html__( 'There are two broad ways to photograph people. You can direct them, or you can document them — watching and waiting for something true to happen on its own.', 'luminance-core' ) . '</p>',
			),
			'getting-ready-on-camera'  => array(
				__( 'How to feel at ease in front of the camera', 'luminance-core' ),
				'<p>' . esc_html__( 'Most people tell me they are not photogenic. Feeling awkward in front of a camera is normal, and it has very little to do with how the photographs actually turn out.', 'luminance-core' ) . '</p>',
			),
			'why-i-shoot-fewer-photos' => array(
				__( 'Why I would rather deliver fewer photographs', 'luminance-core' ),
				'<p>' . esc_html__( 'It is tempting to measure a wedding gallery by the number of images in it. Over the years I have come to believe the opposite: a tighter, carefully chosen edit serves you better.', 'luminance-core' ) . '</p>',
			),
		);
	}

	/**
	 * Just the journal titles (used by the de-duplication routine).
	 *
	 * @return array
	 */
	public static function journal_titles() {
		return array_map(
			static function ( $d ) {
				return $d[0];
			},
			array_values( self::journal_posts() )
		);
	}

	/**
	 * About page body.
	 *
	 * @return string
	 */
	private static function about_body() {
		$paras = array(
			esc_html__( 'Hello — I am the photographer behind Luminance, and I am glad you found your way here. I photograph weddings and events, and the parts people remember most are rarely the ones anyone planned. So that is mostly what I look for.', 'luminance-core' ),
			esc_html__( 'I did not arrive here in a straight line, and I am still learning. I would rather tell you that plainly than pretend the path was effortless.', 'luminance-core' ),
			esc_html__( 'Mostly I stay out of the way, stepping in only when it genuinely helps. The quieter I am, the truer the photographs tend to be.', 'luminance-core' ),
			esc_html__( 'If any of this resonates, I would love to hear about your plans. I read every message myself.', 'luminance-core' ),
		);
		$html = '';
		foreach ( $paras as $p ) {
			$html .= '<p>' . $p . '</p>';
		}
		return $html;
	}

	/**
	 * Contact page body (includes the contact form shortcode).
	 *
	 * @return string
	 */
	private static function contact_body() {
		return '<p>' . esc_html__( 'Tell me about your day — the date, the place, and a little of the story so far. I read every message myself.', 'luminance-core' ) . '</p>' . "\n" . '[luminance_contact]';
	}
}
