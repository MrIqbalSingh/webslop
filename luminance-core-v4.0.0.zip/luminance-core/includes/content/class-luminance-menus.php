<?php
/**
 * Navigation menus: create the Primary and Footer menus once, assign them to
 * theme locations, and keep them free of duplicate items.
 *
 * De-duplication reads the database directly rather than through cached menu
 * helpers, which is what makes it reliable immediately after any change.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Menus
 */
final class Luminance_Menus {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		// Build once, after content exists.
		add_action( 'init', array( __CLASS__, 'maybe_build' ), 99 );
		// Always-on safety pass to collapse any duplicate items.
		add_action( 'init', array( __CLASS__, 'dedupe' ), 101 );
	}

	/**
	 * Build the menus a single time, guarded by an option so later updates
	 * never rebuild and risk stacking duplicates.
	 *
	 * @return void
	 */
	public static function maybe_build() {
		if ( '1' === get_option( 'luminance_menus_built' ) ) {
			return;
		}
		self::build();
		update_option( 'luminance_menus_built', '1' );
	}

	/**
	 * Hard reset and rebuild the Primary and Footer menus.
	 *
	 * @return void
	 */
	public static function build() {
		global $wpdb;

		$pages = self::page_ids();

		// Delete every nav_menu_item outright (meta + relationships + post).
		$item_ids = $wpdb->get_col(
			"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'nav_menu_item'"
		);
		if ( $item_ids ) {
			foreach ( $item_ids as $iid ) {
				$iid = (int) $iid;
				$wpdb->delete( $wpdb->postmeta, array( 'post_id' => $iid ) );
				$wpdb->delete( $wpdb->term_relationships, array( 'object_id' => $iid ) );
				$wpdb->delete( $wpdb->posts, array( 'ID' => $iid ) );
			}
		}

		// Remove duplicate menu objects, then recreate cleanly.
		foreach ( array( 'Primary', 'Footer' ) as $name ) {
			$existing = get_terms(
				array(
					'taxonomy'   => 'nav_menu',
					'hide_empty' => false,
					'name'       => $name,
				)
			);
			if ( ! is_wp_error( $existing ) ) {
				foreach ( $existing as $term ) {
					wp_delete_nav_menu( (int) $term->term_id );
				}
			}
		}

		wp_cache_flush();
		$primary = self::make_menu( 'Primary' );
		$footer  = self::make_menu( 'Footer' );

		self::populate( $primary, $pages );
		self::populate( $footer, $pages );

		// Assign locations for the theme (per-theme mods) and the active theme.
		$slug = get_stylesheet();
		$mods = get_option( 'theme_mods_' . $slug, array() );
		if ( ! is_array( $mods ) ) {
			$mods = array();
		}
		$loc = ( isset( $mods['nav_menu_locations'] ) && is_array( $mods['nav_menu_locations'] ) )
			? $mods['nav_menu_locations'] : array();
		if ( $primary ) {
			$loc['primary'] = $primary;
		}
		if ( $footer ) {
			$loc['footer'] = $footer;
		}
		$mods['nav_menu_locations'] = $loc;
		update_option( 'theme_mods_' . $slug, $mods );
	}

	/**
	 * Populate a menu with the standard set of items, once.
	 *
	 * @param int   $menu_id Menu term ID.
	 * @param array $pages   Map of slug => page ID.
	 * @return void
	 */
	private static function populate( $menu_id, $pages ) {
		if ( ! $menu_id ) {
			return;
		}
		self::add_page( $menu_id, $pages, 'home', __( 'Home', 'luminance-core' ), 1 );
		wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'    => __( 'Portfolio', 'luminance-core' ),
				'menu-item-url'      => home_url( '/portfolio/' ),
				'menu-item-status'   => 'publish',
				'menu-item-type'     => 'custom',
				'menu-item-position' => 2,
			)
		);
		self::add_page( $menu_id, $pages, 'about', __( 'About', 'luminance-core' ), 3 );
		self::add_page( $menu_id, $pages, 'journal', __( 'Journal', 'luminance-core' ), 4 );
		self::add_page( $menu_id, $pages, 'contact', __( 'Contact', 'luminance-core' ), 5 );
	}

	/**
	 * Add a page item to a menu.
	 *
	 * @param int    $menu_id Menu term ID.
	 * @param array  $pages   Map of slug => page ID.
	 * @param string $slug    Page slug key.
	 * @param string $title   Menu label.
	 * @param int    $pos     Position.
	 * @return void
	 */
	private static function add_page( $menu_id, $pages, $slug, $title, $pos ) {
		if ( empty( $pages[ $slug ] ) ) {
			return;
		}
		wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => $title,
				'menu-item-object'    => 'page',
				'menu-item-object-id' => (int) $pages[ $slug ],
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
				'menu-item-position'  => $pos,
			)
		);
	}

	/**
	 * Create a menu by name, recovering its ID if it already exists.
	 *
	 * @param string $name Menu name.
	 * @return int Term ID or 0.
	 */
	private static function make_menu( $name ) {
		$id = wp_create_nav_menu( $name );
		if ( ! is_wp_error( $id ) ) {
			return (int) $id;
		}
		$obj = wp_get_nav_menu_object( $name );
		return $obj ? (int) $obj->term_id : 0;
	}

	/**
	 * Resolve the page IDs the menus link to.
	 *
	 * @return array Map of slug => page ID.
	 */
	private static function page_ids() {
		$ids = array();
		foreach ( array( 'home', 'about', 'contact', 'journal' ) as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page ) {
				$ids[ $slug ] = (int) $page->ID;
			}
		}
		return $ids;
	}

	/**
	 * Collapse duplicate items in every nav menu to one each, via direct SQL.
	 *
	 * @return void
	 */
	public static function dedupe() {
		global $wpdb;

		$menus = get_terms(
			array(
				'taxonomy'   => 'nav_menu',
				'hide_empty' => false,
			)
		);
		if ( is_wp_error( $menus ) || empty( $menus ) ) {
			return;
		}

		foreach ( $menus as $menu ) {
			$item_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT p.ID
					 FROM {$wpdb->posts} p
					 INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
					 WHERE tr.term_taxonomy_id = %d
					   AND p.post_type = 'nav_menu_item'
					   AND p.post_status IN ( 'publish', 'draft' )
					 ORDER BY p.menu_order ASC, p.ID ASC",
					(int) $menu->term_taxonomy_id
				)
			);
			if ( empty( $item_ids ) || count( $item_ids ) <= 1 ) {
				continue;
			}

			$seen = array();
			foreach ( $item_ids as $iid ) {
				$iid  = (int) $iid;
				$type = get_post_meta( $iid, '_menu_item_type', true );
				if ( 'custom' === $type ) {
					$url  = (string) get_post_meta( $iid, '_menu_item_url', true );
					$path = (string) wp_parse_url( $url, PHP_URL_PATH );
					$sig  = 'custom|/' . trim( $path, '/' );
				} else {
					$obj   = get_post_meta( $iid, '_menu_item_object', true );
					$objid = get_post_meta( $iid, '_menu_item_object_id', true );
					$sig   = $type . '|' . $obj . '|' . $objid;
				}
				if ( isset( $seen[ $sig ] ) ) {
					wp_delete_post( $iid, true );
				} else {
					$seen[ $sig ] = true;
				}
			}
		}
	}
}
