<?php
/**
 * Scalability: archive query tuning, a cached accessor for the featured
 * galleries, cache invalidation, and extension hooks for future growth.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Scalability
 */
final class Luminance_Scalability {

	const FEATURED_TRANSIENT = 'luminance_featured_ids';
	const CACHE_TTL          = HOUR_IN_SECONDS;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'pre_get_posts', array( __CLASS__, 'tune_archives' ) );

		// Invalidate the featured cache whenever a gallery changes.
		add_action( 'save_post_' . Luminance_Portfolio::POST_TYPE, array( __CLASS__, 'flush_featured_cache' ) );
		add_action( 'deleted_post', array( __CLASS__, 'flush_featured_cache' ) );
		add_action( 'trashed_post', array( __CLASS__, 'flush_featured_cache' ) );
	}

	/**
	 * Tune front-end archive queries for predictable performance at scale:
	 * a sensible page size and no expensive extras the templates don't use.
	 *
	 * @param WP_Query $query The query.
	 * @return void
	 */
	public static function tune_archives( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}

		// Portfolio archive: paginate in pages of 12 (filterable), ordered by the
		// gallery's "Order" (menu_order) so it matches the home page and respects
		// the Order field set in Quick Edit. Ties fall back to newest first.
		if ( $query->is_post_type_archive( Luminance_Portfolio::POST_TYPE ) || $query->is_tax( Luminance_Portfolio::TAXONOMY ) ) {
			$per_page = (int) apply_filters( 'luminance_portfolio_per_page', 12 );
			$query->set( 'posts_per_page', $per_page );
			$query->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'DESC' ) );
		}

		// Journal (blog) archive: pages of 9 (filterable).
		if ( $query->is_home() ) {
			$per_page = (int) apply_filters( 'luminance_journal_per_page', 9 );
			$query->set( 'posts_per_page', $per_page );
		}
	}

	/**
	 * Cached accessor for the home page "featured work" gallery IDs.
	 *
	 * Caches the query result in a transient so the home page (the most-visited
	 * page) doesn't run the query on every request. Returns an array of post IDs.
	 *
	 * @param int $count How many galleries to feature.
	 * @return int[]
	 */
	public static function get_featured_ids( $count = 6 ) {
		$count  = (int) apply_filters( 'luminance_featured_count', $count );
		$cached = get_transient( self::FEATURED_TRANSIENT );

		if ( is_array( $cached ) ) {
			return array_slice( $cached, 0, $count );
		}

		$ids = get_posts(
			array(
				'post_type'              => Luminance_Portfolio::POST_TYPE,
				'posts_per_page'         => 24, // cache a generous set; slice per call.
				'orderby'                => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
			)
		);

		if ( ! is_array( $ids ) ) {
			$ids = array();
		}

		set_transient( self::FEATURED_TRANSIENT, $ids, self::CACHE_TTL );

		return array_slice( $ids, 0, $count );
	}

	/**
	 * Clear the featured-galleries cache.
	 *
	 * @return void
	 */
	public static function flush_featured_cache() {
		delete_transient( self::FEATURED_TRANSIENT );
	}
}
