<?php
/**
 * Maintenance routines that keep an existing site healthy: journal
 * de-duplication, removal of WordPress's default starter content, and
 * site-URL self-healing after an import/move.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Maintenance
 */
final class Luminance_Maintenance {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'after_setup_theme', array( __CLASS__, 'ensure_theme' ), 1 );
		add_action( 'muplugins_loaded', array( __CLASS__, 'heal_siteurl' ) );
		add_action( 'init', array( __CLASS__, 'manual_menu_fix' ), 100 );
		add_action( 'init', array( __CLASS__, 'remove_default_content' ), 104 );
		add_action( 'init', array( __CLASS__, 'dedupe_journal' ), 105 );
	}

	/**
	 * Self-healing theme activation: if the Luminance Studio theme exists but
	 * is not the active stylesheet, switch to it. Recovers a site whose theme
	 * was changed or overwritten.
	 *
	 * @return void
	 */
	public static function ensure_theme() {
		$theme = wp_get_theme( 'luminance-studio' );
		if ( ! $theme->exists() ) {
			return;
		}
		if ( get_stylesheet() !== 'luminance-studio' ) {
			switch_theme( 'luminance-studio' );
		}
	}

	/**
	 * Manual menu repair: an administrator can visit any URL with
	 * ?luminance_fix_menus=1 to force a clean menu rebuild.
	 *
	 * @return void
	 */
	public static function manual_menu_fix() {
		if ( empty( $_GET['luminance_fix_menus'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( class_exists( 'Luminance_Menus' ) ) {
			Luminance_Menus::build();
		}
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	/**
	 * Correct siteurl/home if they still hold the packaged placeholder domain
	 * after an import, so the site loads on whatever host it now runs under.
	 *
	 * @return void
	 */
	public static function heal_siteurl() {
		if ( ! isset( $_SERVER['HTTP_HOST'] ) || defined( 'WP_CLI' ) ) {
			return;
		}
		$host = sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) );
		if ( ! preg_match( '/^[A-Za-z0-9.\-]+$/', $host ) ) {
			return;
		}
		$https   = isset( $_SERVER['HTTPS'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTPS'] ) ) : '';
		$scheme  = ( '' !== $https && 'off' !== $https ) ? 'https' : 'http';
		$current = $scheme . '://' . $host;

		$stored = get_option( 'siteurl' );
		if ( $stored && $stored !== $current && false !== strpos( (string) $stored, 'luminance-photography.local' ) ) {
			update_option( 'siteurl', $current );
			update_option( 'home', $current );
		}
	}

	/**
	 * Trash the default "Hello world!" post and "Sample Page" once.
	 *
	 * @return void
	 */
	public static function remove_default_content() {
		if ( '1' === get_option( 'luminance_default_content_cleaned' ) ) {
			return;
		}

		$hello = get_page_by_path( 'hello-world', OBJECT, 'post' );
		if ( ! $hello ) {
			$candidate = get_post( 1 );
			if ( $candidate && 'post' === $candidate->post_type && 'Hello world!' === $candidate->post_title ) {
				$hello = $candidate;
			}
		}
		if ( $hello && 'trash' !== $hello->post_status ) {
			wp_trash_post( $hello->ID );
		}

		$sample = get_page_by_path( 'sample-page' );
		if ( $sample && 'trash' !== $sample->post_status ) {
			$front = (int) get_option( 'page_on_front' );
			$blog  = (int) get_option( 'page_for_posts' );
			if ( $sample->ID !== $front && $sample->ID !== $blog ) {
				wp_trash_post( $sample->ID );
			}
		}

		update_option( 'luminance_default_content_cleaned', '1' );
	}

	/**
	 * Collapse duplicate journal posts (by title) to a single copy, keeping the
	 * oldest. Only touches the titles this plugin seeds, so user posts are safe.
	 *
	 * @return void
	 */
	public static function dedupe_journal() {
		global $wpdb;

		$titles   = Luminance_Content::journal_titles();
		$titles[] = 'Five things I look for in a wedding venue';

		foreach ( $titles as $title ) {
			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts}
					 WHERE post_type = 'post'
					   AND post_status = 'publish'
					   AND post_title = %s
					 ORDER BY ID ASC",
					$title
				)
			);
			if ( count( (array) $ids ) <= 1 ) {
				continue;
			}
			array_shift( $ids );
			foreach ( $ids as $dup_id ) {
				wp_trash_post( (int) $dup_id );
			}
		}
	}
}
