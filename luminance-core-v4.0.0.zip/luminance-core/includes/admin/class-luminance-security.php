<?php
/**
 * Security hardening.
 *
 * Conservative, well-established measures that reduce attack surface without
 * breaking normal site behaviour. Each is individually reversible via filters.
 *
 * @package Luminance\Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Luminance_Security
 */
final class Luminance_Security {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		// Hide the WordPress version (it aids targeted attacks on known CVEs).
		add_filter( 'the_generator', '__return_empty_string' );
		remove_action( 'wp_head', 'wp_generator' );

		// Disable XML-RPC: a common brute-force / DDoS amplification vector,
		// unused by this site. Filterable in case pingbacks are ever needed.
		add_filter( 'xmlrpc_enabled', '__return_false' );
		add_filter( 'wp_headers', array( __CLASS__, 'remove_xmlrpc_header' ) );

		// Block REST user-enumeration for anonymous visitors (privacy + recon).
		add_filter( 'rest_endpoints', array( __CLASS__, 'restrict_user_endpoints' ) );

		// Disable author archives / ?author=N enumeration for anonymous probes.
		add_action( 'template_redirect', array( __CLASS__, 'block_author_enumeration' ) );

		// Send conservative security headers on the front end.
		add_filter( 'wp_headers', array( __CLASS__, 'security_headers' ) );

		// Disallow the in-dashboard file editor (limits damage from a hijacked
		// admin session). Respect an existing definition.
		if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}
	}

	/**
	 * Remove the X-Pingback header that advertises XML-RPC.
	 *
	 * @param array $headers HTTP headers.
	 * @return array
	 */
	public static function remove_xmlrpc_header( $headers ) {
		if ( isset( $headers['X-Pingback'] ) ) {
			unset( $headers['X-Pingback'] );
		}
		return $headers;
	}

	/**
	 * Remove the REST users endpoints for unauthenticated requests, so the site
	 * does not leak the list of usernames. Authenticated users with the right
	 * capability are unaffected.
	 *
	 * @param array $endpoints REST endpoints.
	 * @return array
	 */
	public static function restrict_user_endpoints( $endpoints ) {
		if ( is_user_logged_in() ) {
			return $endpoints;
		}
		foreach ( array( '/wp/v2/users', '/wp/v2/users/(?P<id>[\d]+)' ) as $route ) {
			if ( isset( $endpoints[ $route ] ) ) {
				unset( $endpoints[ $route ] );
			}
		}
		return $endpoints;
	}

	/**
	 * Redirect ?author=N enumeration attempts to the home page for anonymous
	 * visitors. This prevents discovery of login usernames via author archives.
	 *
	 * @return void
	 */
	public static function block_author_enumeration() {
		if ( is_admin() || is_user_logged_in() ) {
			return;
		}
		// Only block the ?author=N numeric-ID enumeration probe (used to map
		// user IDs to login names). Legitimate author archives by slug are left
		// intact so nothing in normal navigation breaks.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only check of a public query var.
		if ( isset( $_GET['author'] ) && is_numeric( $_GET['author'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	/**
	 * Add conservative security headers. These are safe defaults for a content
	 * site; a strict Content-Security-Policy is deliberately omitted because it
	 * needs per-site tuning and can break embeds if set blindly.
	 *
	 * @param array $headers HTTP headers.
	 * @return array
	 */
	public static function security_headers( $headers ) {
		if ( is_admin() ) {
			return $headers;
		}
		$headers['X-Content-Type-Options'] = 'nosniff';
		$headers['X-Frame-Options']        = 'SAMEORIGIN';
		$headers['Referrer-Policy']        = 'strict-origin-when-cross-origin';
		$headers['X-XSS-Protection']       = '1; mode=block';
		$headers['Permissions-Policy']     = 'geolocation=(), microphone=(), camera=()';
		return $headers;
	}
}
