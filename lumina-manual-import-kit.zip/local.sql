-- =====================================================
-- LUMINA WEDDING PHOTOGRAPHER - COMPLETE DATABASE DUMP
-- For LocalWP / Local Development Environments
-- Generated for Lumina Theme v1.1 / v1.2
-- =====================================================
-- 
-- HOW TO USE:
-- 1. Create a fresh LocalWP site (WordPress 6.6+)
-- 2. In LocalWP, open Adminer / Sequel Ace / phpMyAdmin
-- 3. Wipe the existing database (optional but recommended)
-- 4. Import this .sql file
-- 5. Copy the wp-content folder from the lumina-v1.1-localwp package
-- 6. Activate Lumina theme + import WPForms form
--
-- Prefix used: wp_
-- =====================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

--
-- Table structure for wp_options
--
DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL,
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES
(1,'siteurl','http://lumawedding.local','yes'),
(2,'home','http://lumawedding.local','yes'),
(3,'blogname','Luna Weddings','yes'),
(4,'blogdescription','Elegant, intentional wedding photography in the Pacific Northwest','yes'),
(5,'users_can_register','0','yes'),
(6,'admin_email','hello@luna.photo','yes'),
(7,'start_of_week','1','yes'),
(8,'use_balanceTags','0','yes'),
(9,'use_smilies','1','yes'),
(10,'require_name_email','1','yes'),
(11,'comments_notify','1','yes'),
(12,'posts_per_rss','10','yes'),
(13,'rss_use_excerpt','0','yes'),
(14,'mailserver_url','','yes'),
(15,'mailserver_login','','yes'),
(16,'mailserver_pass','','yes'),
(17,'mailserver_port','110','yes'),
(18,'default_category','1','yes'),
(19,'default_comment_status','open','yes'),
(20,'default_ping_status','closed','yes'),
(21,'default_pingback_flag','0','yes'),
(22,'posts_per_page','10','yes'),
(23,'date_format','F j, Y','yes'),
(24,'time_format','g:i a','yes'),
(25,'links_updated_date_format','F j, Y g:i a','yes'),
(26,'comment_moderation','0','yes'),
(27,'moderation_notify','1','yes'),
(28,'permalink_structure','/%year%/%monthnum%/%postname%/','yes'),
(29,'rewrite_rules','a:1:{s:16:\"(.?.+?)(?:/([0-9]+))?/?$\";s:38:\"index.php?pagename=$matches[1]&page=$matches[2]\";}','yes'),
(30,'hack_file','0','yes'),
(31,'blog_charset','UTF-8','yes'),
(32,'moderation_keys','','no'),
(33,'active_plugins','a:1:{i:0;s:19:\"wpforms-lite/wpforms.php\";}','yes'),
(34,'template','lumina','yes'),
(35,'stylesheet','lumina','yes'),
(36,'timezone_string','America/Los_Angeles','yes'),
(37,'page_on_front','101','yes'),
(38,'show_on_front','page','yes'),
(39,'default_post_format','','yes'),
(40,'db_version','56657','yes'),
(41,'uploads_use_yearmonth_folders','1','yes'),
(42,'thumbnail_size_w','150','yes'),
(43,'thumbnail_size_h','150','yes'),
(44,'thumbnail_crop','1','yes'),
(45,'medium_size_w','300','yes'),
(46,'medium_size_h','300','yes'),
(47,'large_size_w','1024','yes'),
(48,'large_size_h','1024','yes'),
(49,'image_default_link_type','none','yes'),
(50,'image_default_size','','yes'),
(51,'image_default_align','','yes'),
(52,'close_comments_for_old_posts','0','yes'),
(53,'close_comments_days_old','14','yes'),
(54,'thread_comments','1','yes'),
(55,'thread_comments_depth','5','yes'),
(56,'page_comments','0','yes'),
(57,'comments_per_page','50','yes'),
(58,'default_comments_page','newest','yes'),
(59,'comment_order','asc','yes'),
(60,'sticky_posts','a:0:{}','yes'),
(61,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),
(62,'sidebars_widgets','a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:0:{}}','yes'),
(63,'recently_edited','','yes'),
(64,'theme_mods_lumina','a:4:{s:18:\"custom_logo\";i:0;s:11:\"custom_css\";s:0:\"\";s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:10:\"header_text\";s:0:\"\";}','yes'),
(65,'cron','a:5:{i:1690000000;a:1:{s:20:\"wp_privacy_delete_expired\";a:1:{i:0;a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}}s:7:\"version\";i:2;i:1690100000;a:2:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}s:48:\"wordfence_updateLWPActivityReportCron\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}i:1690500000;a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:7:\"version\";i:2;}','yes');

--
-- Table structure for wp_posts (Pages + Blog Posts)
--
DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES 
(101,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','','Home','','publish','closed','closed','','home','','','2026-05-26 01:00:00','2026-05-26 01:00:00','',0,'http://lumawedding.local/?page_id=101',0,'page','',0),
(102,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','<!-- wp:pattern {\"slug\":\"lumina/about\"} /-->','About','','publish','closed','closed','','about','','','2026-05-26 01:00:00','2026-05-26 01:00:00','',0,'http://lumawedding.local/?page_id=102',2,'page','',0),
(103,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','<!-- wp:pattern {\"slug\":\"lumina/full-portfolio\"} /-->','The Work','','publish','closed','closed','','the-work','','','2026-05-26 01:00:00','2026-05-26 01:00:00','',0,'http://lumawedding.local/?page_id=103',3,'page','',0),
(104,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','<!-- wp:pattern {\"slug\":\"lumina/contact\"} /-->','Contact','','publish','closed','closed','','contact','','','2026-05-26 01:00:00','2026-05-26 01:00:00','',0,'http://lumawedding.local/?page_id=104',4,'page','',0),
(201,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','Last October I photographed a small wedding beside the Columbia River. The light that day was soft and golden...','Behind the Scenes: A Quiet October Wedding in the Gorge','A short personal essay from a recent Pacific Northwest wedding.','publish','open','open','','behind-the-scenes-a-quiet-october-wedding','','','2026-05-26 01:00:00','2026-05-26 01:00:00','',0,'http://lumawedding.local/?p=201',0,'post','',0),
(202,1,'2026-05-25 14:00:00','2026-05-25 14:00:00','My decision to cap at 26 weddings per year comes from a deep desire to stay present...','Why I Only Photograph 26 Weddings a Year','Intentional storytelling requires breathing room. Here’s why I limit my calendar.','publish','open','open','','why-i-only-photograph-26-weddings-a-year','','','2026-05-26 01:00:00','2026-05-26 01:00:00','',0,'http://lumawedding.local/?p=202',0,'post','',0);

--
-- Table structure for wp_postmeta
--
DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES 
(1001,101,'_wp_page_template','front-page'),
(1002,102,'_wp_page_template','page-about'),
(1003,103,'_wp_page_template','page-portfolio'),
(1004,104,'_wp_page_template','page-contact'),
(1005,201,'_thumbnail_id','0'),
(1006,202,'_thumbnail_id','0');

--
-- Table structure for wp_users + wp_usermeta (simple admin)
--
DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES (1,'luna','$P$BM2Q2O4Q8LqJ9d7zK6aF3yV8pW1xT0','luna','hello@luna.photo','','2026-05-26 01:00:00','','0','Luna Rivera');

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES 
(1,1,'nickname','Luna Rivera'),
(2,1,'first_name','Luna'),
(3,1,'last_name','Rivera'),
(4,1,'description',''),
(5,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
(6,1,'wp_user_level','10');

--
-- Terms, Taxonomy, and Menu
--
DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES 
(1,'Uncategorized','uncategorized',0),
(2,'Journal','journal',0),
(3,'Primary Menu','primary-menu',0);

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES 
(1,1,'category','',0,0),
(2,2,'category','',0,2),
(3,3,'nav_menu','',0,4);

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES (201,2,0),(202,2,0);

-- Navigation Menu Items (simple)
INSERT INTO `wp_posts` VALUES 
(301,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','','Home','','publish','open','open','','home','','','',0,'http://lumawedding.local/?p=301',0,'nav_menu_item','',0),
(302,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','','About','','publish','open','open','','about','','','',0,'http://lumawedding.local/?p=302',1,'nav_menu_item','',0),
(303,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','','The Work','','publish','open','open','','the-work','','','',0,'http://lumawedding.local/?p=303',2,'nav_menu_item','',0),
(304,1,'2026-05-26 01:00:00','2026-05-26 01:00:00','','Contact','','publish','open','open','','contact','','','',0,'http://lumawedding.local/?p=304',3,'nav_menu_item','',0);

INSERT INTO `wp_postmeta` VALUES (1011,301,'_menu_item_type','post_type'),(1012,301,'_menu_item_object','page'),(1013,301,'_menu_item_object_id','101');
INSERT INTO `wp_postmeta` VALUES (1014,302,'_menu_item_type','post_type'),(1015,302,'_menu_item_object','page'),(1016,302,'_menu_item_object_id','102');
INSERT INTO `wp_postmeta` VALUES (1017,303,'_menu_item_type','post_type'),(1018,303,'_menu_item_object','page'),(1019,303,'_menu_item_object_id','103');
INSERT INTO `wp_postmeta` VALUES (1020,304,'_menu_item_type','post_type'),(1021,304,'_menu_item_object','page'),(1022,304,'_menu_item_object_id','104');

INSERT INTO `wp_term_relationships` VALUES (301,3,0),(302,3,0),(303,3,0),(304,3,0);

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- END OF LUMINA DATABASE DUMP
-- =====================================================
