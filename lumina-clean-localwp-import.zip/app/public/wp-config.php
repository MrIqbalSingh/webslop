<?php
define("DB_NAME", "local");
define("DB_USER", "root");
define("DB_PASSWORD", "root");
define("DB_HOST", "localhost");
define("DB_CHARSET", "utf8mb4");
define("WP_HOME", "http://lumawedding.local");
define("WP_SITEURL", "http://lumawedding.local");
define("TABLE_PREFIX", "wp_");
define("WP_DEBUG", true);
define("WP_DEFAULT_THEME", "lumina");
if (!defined("ABSPATH")) { define("ABSPATH", __DIR__ . "/"); }
require_once ABSPATH . "wp-settings.php";
