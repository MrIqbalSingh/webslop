/*
 * LUMINA WEDDING PHOTOGRAPHER - SAFE & MINIMAL DATABASE DUMP
 * Compatible with LocalWP (MySQL 8 / MariaDB)
 *
 * This version uses explicit column lists in every INSERT to prevent
 * "Column count doesn't match value count" errors (1136).
 *
 * Strategy: Only insert essential content. Let WordPress create the rest.
 */

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

/* ==============================================
   IMPORTANT: Clear some tables first (safe)
   ============================================== */
/* TRUNCATE wp_posts; is too aggressive on fresh sites - we use REPLACE/INSERT IGNORE pattern instead */

/* ==============================================
   SET KEY OPTIONS (Homepage, Theme, etc.)
   ============================================== */
INSERT INTO `wp_options` (`option_name`, `option_value`, `autoload`) VALUES
('siteurl', 'http://lumawedding.local', 'yes'),
('home', 'http://lumawedding.local', 'yes'),
('blogname', 'Luna Weddings', 'yes'),
('blogdescription', 'Elegant, intentional wedding photography in the Pacific Northwest', 'yes'),
('admin_email', 'hello@luna.photo', 'yes'),
('permalink_structure', '/%year%/%monthnum%/%postname%/', 'yes'),
('show_on_front', 'page', 'yes'),
('page_on_front', '101', 'yes'),
('template', 'lumina', 'yes'),
('stylesheet', 'lumina', 'yes'),
('use_smilies', '1', 'yes'),
('timezone_string', 'America/Los_Angeles', 'yes');

/* ==============================================
   PAGES (Home, About, The Work, Contact)
   ============================================== */
INSERT INTO `wp_posts` 
(`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `post_modified`, `post_modified_gmt`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) 
VALUES
(101, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=101', 0, 'page', '', 0),
(102, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '<!-- wp:pattern {"slug":"lumina/about"} /-->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=102', 2, 'page', '', 0),
(103, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '<!-- wp:pattern {"slug":"lumina/full-portfolio"} /-->', 'The Work', '', 'publish', 'closed', 'closed', '', 'the-work', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=103', 3, 'page', '', 0),
(104, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '<!-- wp:pattern {"slug":"lumina/contact"} /-->', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=104', 4, 'page', '', 0);

/* ==============================================
   BLOG POSTS
   ============================================== */
INSERT INTO `wp_posts` 
(`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `post_modified`, `post_modified_gmt`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) 
VALUES
(201, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', 
 'Last October I photographed a small wedding beside the Columbia River. The light that day was soft and golden...', 
 'Behind the Scenes: A Quiet October Wedding in the Gorge', 
 'A short personal essay from a recent Pacific Northwest wedding.',
 'publish', 'open', 'open', '', 'behind-the-scenes-a-quiet-october-wedding', 
 '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 
 'http://lumawedding.local/?p=201', 0, 'post', '', 0),

(202, 1, '2026-05-25 14:00:00', '2026-05-25 14:00:00',
 'My decision to cap at 26 weddings per year comes from a deep desire to stay present and intentional...',
 'Why I Only Photograph 26 Weddings a Year',
 'Intentional storytelling requires breathing room. Here’s why I limit my calendar.',
 'publish', 'open', 'open', '', 'why-i-only-photograph-26-weddings-a-year',
 '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0,
 'http://lumawedding.local/?p=202', 0, 'post', '', 0);

/* ==============================================
   POSTMETA (Page templates)
   ============================================== */
INSERT INTO `wp_postmeta` (`post_id`, `meta_key`, `meta_value`) VALUES
(101, '_wp_page_template', 'front-page'),
(102, '_wp_page_template', 'page-about'),
(103, '_wp_page_template', 'page-portfolio'),
(104, '_wp_page_template', 'page-contact');

/* ==============================================
   ADMIN USER (simple - password hash for demo)
   ============================================== */
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_registered`, `display_name`) VALUES
(1, 'luna', '$P$BM2Q2O4Q8LqJ9d7zK6aF3yV8pW1xT0', 'luna', 'hello@luna.photo', '2026-05-26 01:00:00', 'Luna Rivera');

INSERT INTO `wp_usermeta` (`user_id`, `meta_key`, `meta_value`) VALUES
(1, 'nickname', 'Luna Rivera'),
(1, 'first_name', 'Luna'),
(1, 'last_name', 'Rivera'),
(1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(1, 'wp_user_level', '10');

/* ==============================================
   NAVIGATION MENU
   ============================================== */
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`) VALUES
(3, 'Primary Menu', 'primary-menu');

INSERT INTO `wp_term_taxonomy` (`term_id`, `taxonomy`, `parent`, `count`) VALUES
(3, 'nav_menu', 0, 4);

/* Menu items (Home, About, The Work, Contact) */
INSERT INTO `wp_posts` 
(`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_status`, `post_name`, `post_parent`, `guid`, `menu_order`, `post_type`)
VALUES
(301, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'Home', 'publish', 'home', 0, 'http://lumawedding.local/?p=301', 0, 'nav_menu_item'),
(302, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'About', 'publish', 'about', 0, 'http://lumawedding.local/?p=302', 1, 'nav_menu_item'),
(303, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'The Work', 'publish', 'the-work', 0, 'http://lumawedding.local/?p=303', 2, 'nav_menu_item'),
(304, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'Contact', 'publish', 'contact', 0, 'http://lumawedding.local/?p=304', 3, 'nav_menu_item');

INSERT INTO `wp_postmeta` (`post_id`, `meta_key`, `meta_value`) VALUES
(301, '_menu_item_type', 'post_type'),
(301, '_menu_item_object', 'page'),
(301, '_menu_item_object_id', '101'),

(302, '_menu_item_type', 'post_type'),
(302, '_menu_item_object', 'page'),
(302, '_menu_item_object_id', '102'),

(303, '_menu_item_type', 'post_type'),
(303, '_menu_item_object', 'page'),
(303, '_menu_item_object_id', '103'),

(304, '_menu_item_type', 'post_type'),
(304, '_menu_item_object', 'page'),
(304, '_menu_item_object_id', '104');

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`) VALUES
(301, 3), (302, 3), (303, 3), (304, 3);

/* ==============================================
   CATEGORIES
   ============================================== */
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`) VALUES (1, 'Uncategorized', 'uncategorized'), (2, 'Journal', 'journal');
INSERT INTO `wp_term_taxonomy` (`term_id`, `taxonomy`, `parent`, `count`) VALUES (1, 'category', 0, 0), (2, 'category', 0, 2);
INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`) VALUES (201, 2), (202, 2);

SET FOREIGN_KEY_CHECKS = 1;

/* End of safe minimal SQL dump for Lumina Wedding Photographer */
