/*
 * LUMINA WEDDING PHOTOGRAPHER - HARDENED MANUAL IMPORT SQL (DROP-FIRST VERSION)
 * Created: 2026-05-26
 *
 * This SQL is designed to work reliably in LocalWP.
 * It always starts by dropping existing tables so you get a clean import.
 *
 * How to use:
 * 1. In LocalWP Adminer, first click "Drop All Tables"
 * 2. Then import this file.
 */

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

/* ============================================================
   DROP ALL CORE WORDPRESS TABLES (Prevents duplicate errors)
   ============================================================ */
DROP TABLE IF EXISTS wp_options;
DROP TABLE IF EXISTS wp_posts;
DROP TABLE IF EXISTS wp_postmeta;
DROP TABLE IF EXISTS wp_users;
DROP TABLE IF EXISTS wp_usermeta;
DROP TABLE IF EXISTS wp_terms;
DROP TABLE IF EXISTS wp_term_taxonomy;
DROP TABLE IF EXISTS wp_term_relationships;
DROP TABLE IF EXISTS wp_comments;
DROP TABLE IF EXISTS wp_commentmeta;
DROP TABLE IF EXISTS wp_links;
DROP TABLE IF EXISTS wp_termmeta;

/* ============================================================
   RECREATE AND POPULATE TABLES (Explicit column lists)
   ============================================================ */

/* --- wp_options --- */
CREATE TABLE wp_options (
  option_id bigint unsigned NOT NULL AUTO_INCREMENT,
  option_name varchar(191) NOT NULL,
  option_value longtext NOT NULL,
  autoload varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (option_id),
  UNIQUE KEY option_name (option_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_options (option_name, option_value, autoload) VALUES
('siteurl', 'http://lumawedding.local', 'yes'),
('home', 'http://lumawedding.local', 'yes'),
('blogname', 'Luna Weddings', 'yes'),
('blogdescription', 'Elegant, intentional wedding photography in the Pacific Northwest', 'yes'),
('admin_email', 'hello@luna.photo', 'yes'),
('users_can_register', '0', 'yes'),
('permalink_structure', '/%year%/%monthnum%/%postname%/', 'yes'),
('show_on_front', 'page', 'yes'),
('page_on_front', '101', 'yes'),
('template', 'lumina', 'yes'),
('stylesheet', 'lumina', 'yes'),
('use_smilies', '1', 'yes'),
('timezone_string', 'America/Los_Angeles', 'yes'),
('start_of_week', '1', 'yes'),
('date_format', 'F j, Y', 'yes'),
('time_format', 'g:i a', 'yes');

/* --- wp_posts (Pages + Blog posts) --- */
CREATE TABLE wp_posts (
  ID bigint unsigned NOT NULL AUTO_INCREMENT,
  post_author bigint unsigned NOT NULL DEFAULT '0',
  post_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  post_date_gmt datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  post_content longtext NOT NULL,
  post_title text NOT NULL,
  post_excerpt text NOT NULL,
  post_status varchar(20) NOT NULL DEFAULT 'publish',
  comment_status varchar(20) NOT NULL DEFAULT 'open',
  ping_status varchar(20) NOT NULL DEFAULT 'open',
  post_password varchar(255) NOT NULL DEFAULT '',
  post_name varchar(200) NOT NULL DEFAULT '',
  to_ping text NOT NULL,
  pinged text NOT NULL,
  post_modified datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  post_modified_gmt datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  post_content_filtered longtext NOT NULL,
  post_parent bigint unsigned NOT NULL DEFAULT '0',
  guid varchar(255) NOT NULL DEFAULT '',
  menu_order int NOT NULL DEFAULT '0',
  post_type varchar(20) NOT NULL DEFAULT 'post',
  post_mime_type varchar(100) NOT NULL DEFAULT '',
  comment_count bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (ID),
  KEY post_name (post_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_posts 
(ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_name, post_modified, post_modified_gmt, post_parent, guid, menu_order, post_type) 
VALUES
(101, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'Home', '', 'publish', 'closed', 'closed', 'home', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=101', 0, 'page'),
(102, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '<!-- wp:pattern {"slug":"lumina/about"} /-->', 'About', '', 'publish', 'closed', 'closed', 'about', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=102', 2, 'page'),
(103, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '<!-- wp:pattern {"slug":"lumina/full-portfolio"} /-->', 'The Work', '', 'publish', 'closed', 'closed', 'the-work', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=103', 3, 'page'),
(104, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '<!-- wp:pattern {"slug":"lumina/contact"} /-->', 'Contact', '', 'publish', 'closed', 'closed', 'contact', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?page_id=104', 4, 'page'),
(201, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', 'Last October I photographed a small wedding beside the Columbia River. The light that day was soft and golden...', 'Behind the Scenes: A Quiet October Wedding in the Gorge', '', 'publish', 'open', 'open', 'behind-the-scenes-a-quiet-october-wedding', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?p=201', 0, 'post'),
(202, 1, '2026-05-25 14:00:00', '2026-05-25 14:00:00', 'My decision to cap at 26 weddings per year comes from a deep desire to stay present...', 'Why I Only Photograph 26 Weddings a Year', '', 'publish', 'open', 'open', 'why-i-only-photograph-26-weddings-a-year', '2026-05-26 01:00:00', '2026-05-26 01:00:00', 0, 'http://lumawedding.local/?p=202', 0, 'post');

/* --- wp_postmeta --- */
CREATE TABLE wp_postmeta (
  meta_id bigint unsigned NOT NULL AUTO_INCREMENT,
  post_id bigint unsigned NOT NULL DEFAULT '0',
  meta_key varchar(255) DEFAULT NULL,
  meta_value longtext,
  PRIMARY KEY (meta_id),
  KEY post_id (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES
(101, '_wp_page_template', 'front-page'),
(102, '_wp_page_template', 'page-about'),
(103, '_wp_page_template', 'page-portfolio'),
(104, '_wp_page_template', 'page-contact');

/* --- wp_users --- */
CREATE TABLE wp_users (
  ID bigint unsigned NOT NULL AUTO_INCREMENT,
  user_login varchar(60) NOT NULL DEFAULT '',
  user_pass varchar(255) NOT NULL DEFAULT '',
  user_nicename varchar(50) NOT NULL DEFAULT '',
  user_email varchar(100) NOT NULL DEFAULT '',
  user_url varchar(100) NOT NULL DEFAULT '',
  user_registered datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  user_activation_key varchar(255) NOT NULL DEFAULT '',
  user_status int NOT NULL DEFAULT '0',
  display_name varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_users (ID, user_login, user_pass, user_nicename, user_email, user_registered, display_name) VALUES
(1, 'luna', '$P$BM2Q2O4Q8LqJ9d7zK6aF3yV8pW1xT0', 'luna', 'hello@luna.photo', '2026-05-26 01:00:00', 'Luna Rivera');

/* --- wp_usermeta --- */
CREATE TABLE wp_usermeta (
  umeta_id bigint unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint unsigned NOT NULL DEFAULT '0',
  meta_key varchar(255) DEFAULT NULL,
  meta_value longtext,
  PRIMARY KEY (umeta_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_usermeta (user_id, meta_key, meta_value) VALUES
(1, 'nickname', 'Luna Rivera'),
(1, 'first_name', 'Luna'),
(1, 'last_name', 'Rivera'),
(1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(1, 'wp_user_level', '10');

/* --- Terms, Taxonomy, Menu --- */
CREATE TABLE wp_terms (
  term_id bigint unsigned NOT NULL AUTO_INCREMENT,
  name varchar(200) NOT NULL DEFAULT '',
  slug varchar(200) NOT NULL DEFAULT '',
  term_group bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (term_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_terms (term_id, name, slug) VALUES
(1, 'Uncategorized', 'uncategorized'),
(2, 'Journal', 'journal'),
(3, 'Primary Menu', 'primary-menu');

CREATE TABLE wp_term_taxonomy (
  term_taxonomy_id bigint unsigned NOT NULL AUTO_INCREMENT,
  term_id bigint unsigned NOT NULL DEFAULT '0',
  taxonomy varchar(32) NOT NULL DEFAULT '',
  description longtext NOT NULL,
  parent bigint unsigned NOT NULL DEFAULT '0',
  count bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (term_taxonomy_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_term_taxonomy (term_id, taxonomy, parent, count) VALUES
(1, 'category', 0, 0),
(2, 'category', 0, 2),
(3, 'nav_menu', 0, 4);

CREATE TABLE wp_term_relationships (
  object_id bigint unsigned NOT NULL DEFAULT '0',
  term_taxonomy_id bigint unsigned NOT NULL DEFAULT '0',
  term_order int NOT NULL DEFAULT '0',
  PRIMARY KEY (object_id, term_taxonomy_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO wp_term_relationships (object_id, term_taxonomy_id) VALUES
(201, 2), (202, 2);

/* Menu items */
INSERT INTO wp_posts 
(ID, post_author, post_date, post_date_gmt, post_content, post_title, post_status, post_name, post_parent, guid, menu_order, post_type)
VALUES
(301, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'Home', 'publish', 'home', 0, 'http://lumawedding.local/?p=301', 0, 'nav_menu_item'),
(302, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'About', 'publish', 'about', 0, 'http://lumawedding.local/?p=302', 1, 'nav_menu_item'),
(303, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'The Work', 'publish', 'the-work', 0, 'http://lumawedding.local/?p=303', 2, 'nav_menu_item'),
(304, 1, '2026-05-26 01:00:00', '2026-05-26 01:00:00', '', 'Contact', 'publish', 'contact', 0, 'http://lumawedding.local/?p=304', 3, 'nav_menu_item');

INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES
(301, '_menu_item_type', 'post_type'), (301, '_menu_item_object', 'page'), (301, '_menu_item_object_id', '101'),
(302, '_menu_item_type', 'post_type'), (302, '_menu_item_object', 'page'), (302, '_menu_item_object_id', '102'),
(303, '_menu_item_type', 'post_type'), (303, '_menu_item_object', 'page'), (303, '_menu_item_object_id', '103'),
(304, '_menu_item_type', 'post_type'), (304, '_menu_item_object', 'page'), (304, '_menu_item_object_id', '104');

INSERT INTO wp_term_relationships (object_id, term_taxonomy_id) VALUES
(301, 3), (302, 3), (303, 3), (304, 3);

SET FOREIGN_KEY_CHECKS = 1;

/* End of hardened "DROP-FIRST" SQL for Lumina Wedding Photographer */

-- STRICT FORCING FOR RICH DESIGN TO APPEAR AFTER IMPORT
REPLACE INTO wp_options (option_name, option_value, autoload) VALUES
('template', 'lumina', 'yes'),
('stylesheet', 'lumina', 'yes'),
('current_theme', 'Lumina', 'yes'),
('show_on_front', 'posts', 'yes'),
('posts_per_page', '10', 'yes');
