LUMINA - Complete Static Wedding Photography Website (2026)

This is a self-contained, high-end static HTML/CSS website for a wedding photographer.

Included Pages:
- index.html          → Beautiful rich homepage with hero, portfolio, testimonials, booking CTA
- about.html          → Warm, personal story + portrait
- services.html       → 3-tier pricing + clear investment packages
- portfolio.html      → Expanded gallery with 6 featured weddings
- blog.html           → Journal listing (3 styled article previews)
- contact.html        → Professional inquiry form + contact details

Design:
- Elegant, editorial wedding photography aesthetic
- Cream / Charcoal / Soft Blush palette
- Playfair Display + clean sans-serif typography
- Fully responsive (mobile-first)
- All pages use consistent navigation

Usage:
1. Open any HTML file in a browser (start with index.html)
2. Replace placeholder images with your own photography
3. Update text and contact info in the pages
4. Host on Netlify, Vercel, GitHub Pages, or any static host

Built from scratch as a clean, production-quality alternative to a full WordPress site.

© 2026 - Created for Luna Rivera / Lumina Wedding Photography
