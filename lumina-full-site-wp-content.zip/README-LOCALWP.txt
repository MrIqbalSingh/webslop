=== LUMINA FULL - Production-Ready WordPress Theme (wp-content ready) ===

This package contains the COMPLETE Lumina Full WordPress theme inside the correct wp-content structure.

HOW TO USE WITH LOCALWP (Recommended):

1. Create a brand new site in LocalWP (WordPress 6.6+ / PHP 8.2 recommended).

2. Stop the site.

3. Navigate in Windows Explorer to:
   C:\Users\YOUR-USERNAME\Local Sites\YOUR-SITE-NAME\app\public\

4. Delete (or rename) the existing "wp-content" folder.

5. Copy the ENTIRE "wp-content" folder from this package and paste it into the path above.

6. Go back to LocalWP and click "Start Site".

7. Activate the theme:
   Appearance > Themes > Activate "Lumina Full"

8. Create these pages for full functionality:
   - About          (use Page Template: About)
   - Services       (use Page Template: Services)
   - Portfolio      (use Page Template: Portfolio)
   - Contact        (use Page Template: Contact)

9. Set the Home page (optional):
   Settings > Reading > Front page displays → A static page → Choose your home page.

10. Replace the placeholder images with your own wedding photography.

That's it. The theme is now fully functional and beautiful.

NOTE:
- This package does NOT work with LocalWP "Import Site" button.
- Use the manual wp-content replacement method above.
- The theme folder is at: wp-content/themes/lumina-full/

Built with care by Kilo Studio.
