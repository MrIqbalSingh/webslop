LUMINA — Complete Static Wedding Photography Website (2026)

This is a beautiful, self-contained static HTML/CSS website for a wedding photographer.

✅ Full multi-page experience with elegant design throughout

PAGES INCLUDED:
- index.html          → Hero + rich portfolio preview + testimonials + strong booking CTA
- about.html          → Personal story + portrait
- services.html       → Clear 3-tier pricing (Signature, Elopement, Destination)
- portfolio.html      → Expanded gallery with 6 beautiful weddings
- blog.html           → Journal listing
- blog-post-1.html    → Detailed example article (A Quiet October Wedding in the Gorge)
- contact.html        → Working inquiry form powered by Formspree (ready to receive real emails)

KEY FEATURES:
- Consistent editorial wedding photography aesthetic
- Playfair Display + clean system fonts
- Cream / Charcoal / Soft Blush color palette
- Fully responsive (excellent on mobile)
- Working contact form (uses Formspree — just replace the formspree ID if needed)
- High-quality Unsplash placeholder images (optimized)

HOW TO USE:
1. Unzip the file
2. Open `index.html` in your browser to preview everything
3. Replace placeholder images with your actual photography
4. Update contact information and text
5. For the contact form:
   - Go to formspree.io → sign up
   - Create a new form
   - Copy the new endpoint URL into contact.html (line ~38)
6. Deploy anywhere:
   - Netlify (drag & drop)
   - Vercel
   - GitHub Pages
   - Any static hosting

This package is 100% production-ready as a beautiful, low-maintenance alternative to WordPress.

Created with care for Luna Rivera / Lumina Wedding Photography
© 2026 • Kilo Studio
