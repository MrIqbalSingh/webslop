<?php
/**
 * Main fallback template (blog / catch-all).
 *
 * @package Luminance
 */

get_header();
?>
<div class="container">
	<header class="page-head">
		<h1 class="page-head__title"><?php is_home() ? bloginfo( 'name' ) : the_archive_title(); ?></h1>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="post-list">
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'post-card' ); ?>>
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="post-card__media" href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail( 'luminance-landscape', array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 760px) 100vw, 700px' ) ); ?>
						</a>
					<?php endif; ?>
					<div class="post-card__body">
						<h2 class="post-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p class="post-card__meta"><?php echo esc_html( get_the_date() ); ?></p>
						<div class="post-card__excerpt"><?php the_excerpt(); ?></div>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<div class="pagination"><?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?></div>
	<?php else : ?>
		<p><?php esc_html_e( 'Nothing here yet.', 'luminance-studio' ); ?></p>
	<?php endif; ?>
</div>
<?php get_footer();
