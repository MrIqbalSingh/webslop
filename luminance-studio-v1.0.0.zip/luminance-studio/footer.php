<?php
/**
 * Footer template.
 *
 * @package Luminance
 */
?>
</main><!-- #main -->

<footer class="site-footer">
	<div class="site-footer__inner">
		<div class="site-footer__brand">
			<span class="site-footer__mark"><?php bloginfo( 'name' ); ?></span>
			<p class="site-footer__tagline"><?php bloginfo( 'description' ); ?></p>
		</div>

		<nav class="site-footer__nav" aria-label="<?php esc_attr_e( 'Footer', 'luminance-studio' ); ?>">
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'menu_class'     => 'site-footer__list',
					'fallback_cb'    => false,
					'depth'          => 1,
				) );
			} else {
				luminance_nav_fallback( array( 'menu_class' => 'site-footer__list', 'echo' => true ) );
			}
			?>
		</nav>

		<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
			<div class="site-footer__widgets">
				<?php dynamic_sidebar( 'footer-1' ); ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="site-footer__base">
		<p>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All photographs displayed are placeholder imagery.', 'luminance-studio' ); ?></p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
