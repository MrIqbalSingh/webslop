<?php
/**
 * Single gallery view.
 *
 * @package Luminance
 */
get_header();
while ( have_posts() ) : the_post();
	$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
?>
<article <?php post_class( 'gallery-single' ); ?>>
	<header class="gallery-single__head" <?php if ( has_post_thumbnail() ) : ?>style="--g-img:url('<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'luminance-hero' ) ); ?>')"<?php endif; ?>>
		<div class="gallery-single__overlay"></div>
		<div class="gallery-single__intro">
			<?php if ( $terms && ! is_wp_error( $terms ) ) : ?>
				<p class="gallery-single__kicker"><?php echo esc_html( $terms[0]->name ); ?></p>
			<?php endif; ?>
			<h1 class="gallery-single__title"><?php the_title(); ?></h1>
		</div>
	</header>

	<div class="container container--narrow">
		<div class="gallery-single__body">
			<?php the_content(); ?>
		</div>

		<nav class="gallery-nav">
			<?php previous_post_link( '<span class="gallery-nav__prev">%link</span>', '&lsaquo; Previous' ); ?>
			<a class="gallery-nav__all" href="<?php echo esc_url( get_post_type_archive_link( 'portfolio' ) ); ?>">All galleries</a>
			<?php next_post_link( '<span class="gallery-nav__next">%link</span>', 'Next &rsaquo;' ); ?>
		</nav>
	</div>
</article>
<?php
endwhile;
get_footer();
