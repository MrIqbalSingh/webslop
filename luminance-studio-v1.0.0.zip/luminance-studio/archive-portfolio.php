<?php
/**
 * Portfolio archive — filterable gallery grid.
 *
 * @package Luminance
 */
get_header();
?>
<div class="container">
	<header class="page-head">
		<p class="page-head__kicker">Portfolio</p>
		<h1 class="page-head__title">Galleries</h1>
		<p class="page-head__lede">A living archive of weddings, celebrations and events. Browse by collection or wander through it all.</p>
	</header>

	<?php
	$collections = get_terms( array( 'taxonomy' => 'portfolio_category', 'hide_empty' => true ) );
	if ( $collections && ! is_wp_error( $collections ) ) :
		?>
		<nav class="filter" aria-label="<?php esc_attr_e( 'Filter galleries', 'luminance-studio' ); ?>">
			<button class="filter__btn is-active" data-filter="*">All</button>
			<?php foreach ( $collections as $c ) : ?>
				<button class="filter__btn" data-filter=".cat-<?php echo esc_attr( $c->slug ); ?>"><?php echo esc_html( $c->name ); ?></button>
			<?php endforeach; ?>
		</nav>
	<?php endif; ?>

	<div class="masonry" data-grid>
		<?php
		if ( have_posts() ) :
			while ( have_posts() ) : the_post();
				$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
				$classes = '';
				if ( $terms && ! is_wp_error( $terms ) ) {
					foreach ( $terms as $t ) { $classes .= ' cat-' . $t->slug; }
				}
				?>
				<a class="masonry__item<?php echo esc_attr( $classes ); ?>" href="<?php the_permalink(); ?>">
					<?php if ( has_post_thumbnail() ) : ?>
						<?php the_post_thumbnail( 'full', array( 'loading' => 'lazy', 'decoding' => 'async', 'class' => 'masonry__img', 'sizes' => '(max-width: 520px) 100vw, (max-width: 980px) 50vw, 33vw' ) ); ?>
					<?php endif; ?>
					<span class="masonry__caption">
						<span class="masonry__title"><?php the_title(); ?></span>
						<?php if ( $terms && ! is_wp_error( $terms ) ) : ?>
							<span class="masonry__cat"><?php echo esc_html( $terms[0]->name ); ?></span>
						<?php endif; ?>
					</span>
				</a>
				<?php
			endwhile;
		else :
			echo '<p>No galleries yet.</p>';
		endif;
		?>
	</div>
	<div class="pagination"><?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?></div>
</div>
<?php get_footer();
