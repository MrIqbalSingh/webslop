<?php
/**
 * Default page template.
 *
 * @package Luminance
 */
get_header();
while ( have_posts() ) : the_post();
?>
<article <?php post_class( 'single-page' ); ?>>
	<header class="page-head">
		<h1 class="page-head__title"><?php the_title(); ?></h1>
	</header>
	<div class="container container--narrow">
		<div class="entry-content"><?php the_content(); ?></div>
	</div>
</article>
<?php
endwhile;
get_footer();
