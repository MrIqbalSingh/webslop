<?php
/**
 * Single blog post.
 *
 * @package Luminance
 */
get_header();
while ( have_posts() ) : the_post();
?>
<article <?php post_class( 'single-page' ); ?>>
	<header class="page-head">
		<p class="page-head__kicker"><?php echo esc_html( get_the_date() ); ?></p>
		<h1 class="page-head__title"><?php the_title(); ?></h1>
	</header>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="container container--narrow"><?php
			the_post_thumbnail(
				'luminance-hero',
				array(
					'sizes'         => '(max-width: 800px) 100vw, 800px',
					'decoding'      => 'async',
					'fetchpriority' => 'high',
				)
			);
		?></div>
	<?php endif; ?>
	<div class="container container--narrow">
		<div class="entry-content"><?php the_content(); ?></div>
	</div>
</article>
<?php
endwhile;
get_footer();
