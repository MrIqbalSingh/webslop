<?php
/**
 * Luminance — theme functions & definitions.
 *
 * A deliberately lean functions file. No frameworks, no jQuery dependency,
 * no render-blocking bloat. Everything here serves performance or the
 * photographer's portfolio workflow.
 *
 * @package Luminance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LUMINANCE_VERSION', '1.0.0' );

/* -------------------------------------------------------------------------
 * 1. Theme setup
 * ---------------------------------------------------------------------- */
function luminance_setup() {
	load_theme_textdomain( 'luminance-studio', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 320, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );

	// Portfolio-friendly image sizes.
	add_image_size( 'luminance-portrait', 800, 1000, true );
	add_image_size( 'luminance-landscape', 1200, 800, true );
	add_image_size( 'luminance-hero', 1920, 1280, true );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'luminance-studio' ),
		'footer'  => __( 'Footer Menu', 'luminance-studio' ),
	) );
}
add_action( 'after_setup_theme', 'luminance_setup' );

/* -------------------------------------------------------------------------
 * 2. Assets — single minified-style CSS, tiny vanilla JS, fonts preconnected
 * ---------------------------------------------------------------------- */
function luminance_assets() {
	$theme_uri = get_template_directory_uri();
	$theme_dir = get_template_directory();

	// Prefer minified assets, fall back to the readable source if a .min file
	// is missing. Version is the mtime of whichever file is actually served.
	$css_rel = file_exists( $theme_dir . '/assets/css/main.min.css' )
		? '/assets/css/main.min.css'
		: '/assets/css/main.css';
	$js_rel  = file_exists( $theme_dir . '/assets/js/main.min.js' )
		? '/assets/js/main.min.js'
		: '/assets/js/main.js';

	$css_ver = file_exists( $theme_dir . $css_rel )
		? filemtime( $theme_dir . $css_rel )
		: LUMINANCE_VERSION;
	$js_ver  = file_exists( $theme_dir . $js_rel )
		? filemtime( $theme_dir . $js_rel )
		: LUMINANCE_VERSION;

	// Fonts. Loaded with media-swap so they never block first paint:
	// request as print, then flip to all once downloaded (progressive).
	wp_enqueue_style(
		'luminance-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Jost:wght@300;400;500&display=swap',
		array(),
		null
	);

	wp_enqueue_style(
		'luminance-main',
		$theme_uri . $css_rel,
		array(),
		$css_ver
	);

	// Core interaction script (nav, sticky header, reveals): site-wide, deferred.
	wp_enqueue_script(
		'luminance-main',
		$theme_uri . $js_rel,
		array(),
		$js_ver,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'luminance_assets' );

/**
 * Load fonts without blocking render: switch the stylesheet's media from
 * "print" to "all" once it has downloaded. Progressive enhancement — a
 * <noscript> fallback keeps fonts working with JS disabled.
 *
 * @param string $html   The link tag HTML.
 * @param string $handle The enqueued handle.
 * @return string
 */
function luminance_async_fonts( $html, $handle ) {
	if ( 'luminance-fonts' !== $handle ) {
		return $html;
	}
	$async = str_replace(
		"media='all'",
		"media='print' onload=\"this.media='all'\"",
		$html
	);
	// If WordPress didn't add media='all', append the swap attributes.
	if ( $async === $html ) {
		$async = str_replace( ' />', " media='print' onload=\"this.media='all'\" />", $html );
	}
	$async .= '<noscript>' . $html . '</noscript>';
	return $async;
}
add_filter( 'style_loader_tag', 'luminance_async_fonts', 10, 2 );

/**
 * Preload the Largest Contentful Paint image so it starts downloading early.
 * On the front page that is the hero background; on a single gallery it is the
 * header image. Preloading these measurably improves LCP.
 *
 * @return void
 */
function luminance_preload_lcp() {
	$hrefs = array();

	if ( is_front_page() ) {
		// Desktop LCP: the hero background image.
		$hrefs[] = content_url( '/uploads/portfolio/hero-ceremony.jpg' );

		// Mobile LCP: the first featured gallery thumbnail. Mirror the home
		// page's ordering so we preload the exact image that renders first.
		$first = get_posts( array(
			'post_type'              => 'portfolio',
			'posts_per_page'         => 1,
			'orderby'                => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
		) );
		if ( ! empty( $first ) ) {
			$thumb = get_the_post_thumbnail_url( (int) $first[0], 'full' );
			if ( $thumb ) {
				$hrefs[] = $thumb;
			}
		}
	} elseif ( is_singular( 'portfolio' ) && has_post_thumbnail() ) {
		$hrefs[] = get_the_post_thumbnail_url( get_the_ID(), 'luminance-hero' );
	}

	foreach ( array_unique( array_filter( $hrefs ) ) as $href ) {
		printf(
			'<link rel="preload" as="image" href="%s" fetchpriority="high" />' . "\n",
			esc_url( $href )
		);
	}
}
add_action( 'wp_head', 'luminance_preload_lcp', 1 );

/**
 * Output a meta description. Uses the site tagline on the front page and an
 * excerpt on single posts/pages, so search engines and social previews have a
 * concise summary. Kept lightweight; a dedicated SEO plugin can override this.
 *
 * @return void
 */
function luminance_meta_description() {
	$desc = '';

	if ( is_front_page() ) {
		$desc = get_bloginfo( 'description' );
		if ( ! $desc ) {
			$desc = __( 'Wedding and event photography in a warm, documentary style — galleries, journal and enquiries.', 'luminance-studio' );
		}
	} elseif ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( $post->post_content ), 30, '…' );
		}
	} elseif ( is_post_type_archive( 'portfolio' ) || is_tax( 'portfolio_category' ) ) {
		$desc = __( 'A living archive of weddings, celebrations and events.', 'luminance-studio' );
	}

	$desc = trim( wp_strip_all_tags( (string) $desc ) );
	if ( '' === $desc ) {
		return;
	}
	printf(
		'<meta name="description" content="%s" />' . "\n",
		esc_attr( wp_html_excerpt( $desc, 160, '…' ) )
	);
}
add_action( 'wp_head', 'luminance_meta_description', 2 );


// Preconnect to font CDNs for faster first paint.
function luminance_resource_hints( $hints, $relation ) {
	if ( 'preconnect' === $relation ) {
		$hints[] = array( 'href' => 'https://fonts.googleapis.com' );
		$hints[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $hints;
}
add_filter( 'wp_resource_hints', 'luminance_resource_hints', 10, 2 );

/* -------------------------------------------------------------------------
 * 3. Performance — strip the cruft WordPress ships by default
 * ---------------------------------------------------------------------- */
function luminance_cleanup() {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );

	// oEmbed discovery links + host JS: a photography site rarely needs to be
	// embedded elsewhere, and this removes a script and two <link>s per page.
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'wp_oembed_add_host_js' );

	// Disable emoji script/style payload (saves a request + inline JS).
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', 'luminance_cleanup' );

// Remove WordPress's default block/global CSS on the front end. This theme is
// hand-built and does not rely on block-editor styles; that core CSS also
// applies content-visibility + a default contain-intrinsic-size to images,
// which can stretch grid thumbnails. Dequeuing it removes the bloat and the
// stretch in one move.
function luminance_trim_global_styles() {
	wp_dequeue_style( 'wp-block-library' );        // core block styles
	wp_dequeue_style( 'wp-block-library-theme' );  // theme-specific block styles
	wp_dequeue_style( 'global-styles' );           // theme.json global styles (intrinsic-size source)
	wp_dequeue_style( 'classic-theme-styles' );    // classic theme shim
	wp_dequeue_style( 'wc-blocks-style' );          // harmless if absent
}
add_action( 'wp_enqueue_scripts', 'luminance_trim_global_styles', 100 );

// Belt-and-braces: also remove the global inline styles at their source hooks,
// which fire reliably regardless of enqueue timing. This is what actually
// strips the contain-intrinsic-size / content-visibility rules applied to imgs.
remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
add_action( 'init', 'luminance_remove_global_styles_hooks' );
function luminance_remove_global_styles_hooks() {
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
	remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
	// Stop the editor/theme.json from emitting the SVG filters + presets too.
	remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
	remove_action( 'wp_footer', 'the_block_template_skip_link' );
}

/* -------------------------------------------------------------------------
 * 4. Portfolio custom post type + taxonomy
 * ---------------------------------------------------------------------- */
function luminance_portfolio_cpt() {
	register_post_type( 'portfolio', array(
		'labels' => array(
			'name'               => __( 'Portfolio', 'luminance-studio' ),
			'singular_name'      => __( 'Gallery', 'luminance-studio' ),
			'add_new_item'       => __( 'Add New Gallery', 'luminance-studio' ),
			'edit_item'          => __( 'Edit Gallery', 'luminance-studio' ),
			'all_items'          => __( 'All Galleries', 'luminance-studio' ),
		),
		'public'       => true,
		'has_archive'  => true,
		'menu_icon'    => 'dashicons-camera',
		'rewrite'      => array( 'slug' => 'portfolio' ),
		'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
		'show_in_rest' => true,
	) );

	register_taxonomy( 'portfolio_category', 'portfolio', array(
		'labels' => array(
			'name'          => __( 'Collections', 'luminance-studio' ),
			'singular_name' => __( 'Collection', 'luminance-studio' ),
		),
		'hierarchical' => true,
		'public'       => true,
		'rewrite'      => array( 'slug' => 'collection' ),
		'show_in_rest' => true,
	) );
}
/*
 * Register the Portfolio CPT only if the Luminance Core plugin is not present.
 * The plugin owns this functionality (so it survives theme switches); the theme
 * keeps a fallback registration so the site still works if the plugin is
 * inactive. The guard prevents double registration during/after cutover.
 */
if ( ! class_exists( 'Luminance_Portfolio' ) ) {
	add_action( 'init', 'luminance_portfolio_cpt' );
}

/* -------------------------------------------------------------------------
 * 5. Lightweight built-in contact form (no external plugin required)
 *    Shortcode: [luminance_contact]
 *    Uses a nonce + honeypot; sends via wp_mail to the admin address.
 * ---------------------------------------------------------------------- */
function luminance_contact_form_shortcode() {
	$status = '';

	if ( isset( $_POST['luminance_contact_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['luminance_contact_nonce'] ) ), 'luminance_contact' ) ) {
		// Honeypot: real users leave this empty.
		if ( empty( $_POST['lum_website'] ) ) {
			$name    = isset( $_POST['lum_name'] ) ? sanitize_text_field( wp_unslash( $_POST['lum_name'] ) ) : '';
			$email   = isset( $_POST['lum_email'] ) ? sanitize_email( wp_unslash( $_POST['lum_email'] ) ) : '';
			$date    = isset( $_POST['lum_date'] ) ? sanitize_text_field( wp_unslash( $_POST['lum_date'] ) ) : '';
			$type    = isset( $_POST['lum_type'] ) ? sanitize_text_field( wp_unslash( $_POST['lum_type'] ) ) : '';
			$message = isset( $_POST['lum_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['lum_message'] ) ) : '';

			if ( $name && is_email( $email ) && $message ) {
				$to      = get_option( 'admin_email' );
				$subject = sprintf( '[%s] New enquiry from %s', get_bloginfo( 'name' ), $name );
				$body    = "Name: {$name}\nEmail: {$email}\nEvent date: {$date}\nEvent type: {$type}\n\nMessage:\n{$message}\n";
				$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

				wp_mail( $to, $subject, $body, $headers );
				$status = '<p class="lum-form-success" role="status">Thank you — your enquiry has been sent. I usually reply within 24 hours.</p>';
			} else {
				$status = '<p class="lum-form-error" role="alert">Please complete the name, a valid email, and a message.</p>';
			}
		}
	}

	ob_start();
	?>
	<form class="lum-contact-form" method="post" action="">
		<?php echo $status; // phpcs:ignore ?>
		<div class="lum-field-row">
			<label class="lum-field">
				<span>Your name</span>
				<input type="text" name="lum_name" required>
			</label>
			<label class="lum-field">
				<span>Email address</span>
				<input type="email" name="lum_email" required>
			</label>
		</div>
		<div class="lum-field-row">
			<label class="lum-field">
				<span>Event date</span>
				<input type="date" name="lum_date">
			</label>
			<label class="lum-field">
				<span>Event type</span>
				<select name="lum_type">
					<option value="Wedding">Wedding</option>
					<option value="Engagement">Engagement</option>
					<option value="Corporate / Gala">Corporate / Gala</option>
					<option value="Celebration">Celebration</option>
					<option value="Other">Other</option>
				</select>
			</label>
		</div>
		<label class="lum-field">
			<span>Tell me about your day</span>
			<textarea name="lum_message" rows="5" required></textarea>
		</label>
		<input type="text" name="lum_website" class="lum-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
		<?php wp_nonce_field( 'luminance_contact', 'luminance_contact_nonce' ); ?>
		<button type="submit" class="lum-btn">Send enquiry</button>
	</form>
	<?php
	return ob_get_clean();
}
/*
 * Register the contact shortcode only if the plugin isn't providing it. The
 * plugin's version (with hardened output escaping) takes precedence; this
 * remains as a fallback for when the plugin is inactive.
 */
if ( ! class_exists( 'Luminance_Contact_Form' ) ) {
	add_shortcode( 'luminance_contact', 'luminance_contact_form_shortcode' );
}

/* -------------------------------------------------------------------------
 * 6. Widgets / sidebars
 * ---------------------------------------------------------------------- */
function luminance_widgets() {
	register_sidebar( array(
		'name'          => __( 'Footer', 'luminance-studio' ),
		'id'            => 'footer-1',
		'before_widget' => '<div class="footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget__title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'luminance_widgets' );

/* -------------------------------------------------------------------------
 * 7. Excerpt tweaks
 * ---------------------------------------------------------------------- */
function luminance_excerpt_length() { return 24; }
add_filter( 'excerpt_length', 'luminance_excerpt_length' );

function luminance_excerpt_more() { return '&hellip;'; }
add_filter( 'excerpt_more', 'luminance_excerpt_more' );

/* Body classes for styling hooks. */
function luminance_body_classes( $classes ) {
	if ( ! is_singular() ) {
		$classes[] = 'is-listing';
	}
	return $classes;
}
add_filter( 'body_class', 'luminance_body_classes' );

/**
 * Remove width/height attributes from masonry grid thumbnails.
 *
 * The grid uses CSS columns with proportional scaling (width:100%; height:auto).
 * If the <img> keeps its native height attribute, some browsers lock a fixed
 * intrinsic height and stretch the thumbnail into a tall strip. Stripping the
 * dimension attributes for these specific images lets them scale naturally,
 * independent of any CSS caching.
 *
 * @param string $html The <img> HTML.
 * @return string
 */
function luminance_strip_masonry_dimensions( $html ) {
	if ( false === strpos( $html, 'masonry__img' ) ) {
		return $html;
	}
	$html = preg_replace( '/\s(width|height)="\d+"/', '', $html );
	return $html;
}
add_filter( 'post_thumbnail_html', 'luminance_strip_masonry_dimensions' );

/**
 * Disable the "auto-sizes for lazy-loaded images" feature (WP 6.5+). It prepends
 * sizes="auto" and participates in the intrinsic-size behaviour that can stretch
 * grid thumbnails. The theme sets explicit sizes already, so this is safe.
 */
add_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );

/**
 * Belt-and-braces: ensure masonry thumbnails never carry content-visibility or
 * a contain-intrinsic-size inline. Strips any style attribute WordPress global
 * styles might inline onto these specific images.
 *
 * @param string $html The <img> HTML.
 * @return string
 */
function luminance_clean_masonry_style( $html ) {
	if ( false === strpos( $html, 'masonry__img' ) ) {
		return $html;
	}
	$html = preg_replace( '/\sstyle="[^"]*"/', '', $html );
	return $html;
}
add_filter( 'post_thumbnail_html', 'luminance_clean_masonry_style' );

/* -------------------------------------------------------------------------
 * 8. Navigation fallback
 * Renders a sensible menu (key pages + portfolio) when no menu is assigned
 * to a location, so navigation is never empty.
 * ---------------------------------------------------------------------- */
function luminance_nav_fallback( $args = array() ) {
	$items = array();

	$home = home_url( '/' );
	$items[] = '<li class="menu-item"><a href="' . esc_url( $home ) . '">' . esc_html__( 'Home', 'luminance-studio' ) . '</a></li>';
	$items[] = '<li class="menu-item"><a href="' . esc_url( home_url( '/portfolio/' ) ) . '">' . esc_html__( 'Portfolio', 'luminance-studio' ) . '</a></li>';

	foreach ( array( 'about' => 'About', 'journal' => 'Journal', 'contact' => 'Contact' ) as $slug => $label ) {
		$page = get_page_by_path( $slug );
		if ( $page ) {
			$items[] = '<li class="menu-item"><a href="' . esc_url( get_permalink( $page->ID ) ) . '">' . esc_html( $label ) . '</a></li>';
		}
	}

	$class = ( is_array( $args ) && isset( $args['menu_class'] ) ) ? $args['menu_class'] : 'site-nav__list';
	$html  = '<ul class="' . esc_attr( $class ) . '">' . implode( '', $items ) . '</ul>';

	// Honor wp_nav_menu's echo contract exactly: echo only when echo is truthy
	// (default), and return only when explicitly asked not to echo. Doing both
	// causes the menu to render twice.
	$echo = ( is_array( $args ) && array_key_exists( 'echo', $args ) ) ? $args['echo'] : true;
	if ( $echo ) {
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return;
	}
	return $html;
}

/* -------------------------------------------------------------------------
 * 9. Block bogus theme update prompts
 * This theme is custom and self-contained — it is not hosted on WordPress.org.
 * WordPress can mistakenly offer an "update" if a same-named theme exists in
 * the public directory, and applying it would OVERWRITE this theme. We defend
 * against that by removing this theme from the update payload entirely.
 * ---------------------------------------------------------------------- */
function luminance_block_theme_update( $value ) {
	if ( isset( $value->response ) && is_array( $value->response ) ) {
		unset( $value->response['luminance-studio'] );
		// Also guard against any legacy slug lingering in the payload.
		unset( $value->response['luminance'] );
	}
	return $value;
}
add_filter( 'site_transient_update_themes', 'luminance_block_theme_update' );
