/* Luminance — vanilla JS, no dependencies. Progressive enhancement only. */
(function () {
	'use strict';

	var prefersReduced = window.matchMedia &&
		window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* ---------------------------------------------------------------
	 * Mobile nav toggle (with body scroll lock + Escape to close)
	 * ------------------------------------------------------------ */
	var toggle = document.querySelector('[data-nav-toggle]');
	var nav = document.getElementById('primary-nav');
	if (toggle && nav) {
		var setOpen = function (open) {
			nav.classList.toggle('is-open', open);
			toggle.classList.toggle('is-active', open);
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			document.body.classList.toggle('nav-open', open);
		};
		toggle.addEventListener('click', function () {
			setOpen(!nav.classList.contains('is-open'));
		});
		nav.addEventListener('click', function (e) {
			if (e.target.tagName === 'A') { setOpen(false); }
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && nav.classList.contains('is-open')) {
				setOpen(false);
				toggle.focus(); // return focus to the control that opened it
			}
		});
	}

	/* ---------------------------------------------------------------
	 * Sticky header: shadow + hide-on-scroll-down / show-on-scroll-up
	 * ------------------------------------------------------------ */
	var header = document.querySelector('[data-header]');
	if (header) {
		var lastY = window.scrollY;
		var ticking = false;
		var update = function () {
			var y = window.scrollY;
			header.classList.toggle('is-scrolled', y > 20);
			if (!nav || !nav.classList.contains('is-open')) {
				if (y > lastY && y > 240) {
					header.classList.add('is-hidden');
				} else {
					header.classList.remove('is-hidden');
				}
			}
			lastY = y;
			ticking = false;
		};
		window.addEventListener('scroll', function () {
			if (!ticking) { window.requestAnimationFrame(update); ticking = true; }
		}, { passive: true });
		update();
	}

	/* ---------------------------------------------------------------
	 * Scroll reveal: fade/rise elements as they enter the viewport
	 * ------------------------------------------------------------ */
	var revealEls = document.querySelectorAll('[data-reveal], .masonry__item, .service, .entry-content > *, .testimonial__inner');
	if (revealEls.length) {
		if (prefersReduced || !('IntersectionObserver' in window)) {
			revealEls.forEach(function (el) { el.classList.add('is-visible'); });
		} else {
			revealEls.forEach(function (el) { el.classList.add('reveal'); });
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						entry.target.classList.add('is-visible');
						io.unobserve(entry.target);
					}
				});
			}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
			revealEls.forEach(function (el) { io.observe(el); });
		}
	}

	/* ---------------------------------------------------------------
	 * Portfolio filtering with smooth fade
	 * ------------------------------------------------------------ */
	var filterBtns = document.querySelectorAll('.filter__btn');
	var grid = document.querySelector('[data-grid]');
	if (filterBtns.length && grid) {
		var items = grid.querySelectorAll('.masonry__item');
		filterBtns.forEach(function (btn) {
			btn.addEventListener('click', function () {
				filterBtns.forEach(function (b) {
					b.classList.remove('is-active');
					b.setAttribute('aria-pressed', 'false');
				});
				btn.classList.add('is-active');
				btn.setAttribute('aria-pressed', 'true');
				var f = btn.getAttribute('data-filter');
				items.forEach(function (item) {
					var show = f === '*' || item.matches(f);
					item.classList.toggle('is-hidden', !show);
				});
			});
		});
	}

	/* ---------------------------------------------------------------
	 * Lightbox for portfolio / gallery images
	 * ------------------------------------------------------------ */
	var lightboxTargets = document.querySelectorAll('.gallery-single__body img, .gallery-grid img, [data-lightbox] img');
	if (lightboxTargets.length) {
		var box = document.createElement('div');
		box.className = 'lum-lightbox';
		box.setAttribute('aria-hidden', 'true');
		box.setAttribute('role', 'dialog');
		box.setAttribute('aria-modal', 'true');
		box.setAttribute('aria-label', 'Image viewer');
		box.innerHTML =
			'<button class="lum-lightbox__close" aria-label="Close">&times;</button>' +
			'<button class="lum-lightbox__nav lum-lightbox__prev" aria-label="Previous">&#8249;</button>' +
			'<figure class="lum-lightbox__stage"><img alt=""></figure>' +
			'<button class="lum-lightbox__nav lum-lightbox__next" aria-label="Next">&#8250;</button>';
		document.body.appendChild(box);

		var stageImg = box.querySelector('img');
		var list = Array.prototype.slice.call(lightboxTargets);
		var current = -1;
		var lastFocused = null; // element to restore focus to on close

		// Elements that can receive focus inside the dialog (for the focus trap).
		var focusable = function () {
			return Array.prototype.slice.call(
				box.querySelectorAll('button:not([disabled])')
			);
		};

		var srcFor = function (img) {
			var a = img.closest('a');
			if (a && /\.(jpe?g|png|webp|gif)$/i.test(a.getAttribute('href') || '')) {
				return a.getAttribute('href');
			}
			return img.currentSrc || img.src;
		};
		var show = function (i) {
			current = (i + list.length) % list.length;
			stageImg.src = srcFor(list[current]);
			stageImg.alt = list[current].alt || '';
		};
		var open = function (i) {
			lastFocused = document.activeElement; // remember where focus was
			show(i);
			box.classList.add('is-open');
			box.setAttribute('aria-hidden', 'false');
			document.body.classList.add('nav-open');
			// Move focus into the dialog (the close button) for keyboard users.
			var closeBtn = box.querySelector('.lum-lightbox__close');
			if (closeBtn) { closeBtn.focus(); }
		};
		var close = function () {
			box.classList.remove('is-open');
			box.setAttribute('aria-hidden', 'true');
			document.body.classList.remove('nav-open');
			// Restore focus to the thumbnail/link that opened the dialog.
			if (lastFocused && typeof lastFocused.focus === 'function') {
				lastFocused.focus();
			}
		};

		list.forEach(function (img, i) {
			img.style.cursor = 'zoom-in';
			var trigger = img.closest('a') || img;
			trigger.addEventListener('click', function (e) {
				e.preventDefault();
				open(i);
			});
		});
		box.querySelector('.lum-lightbox__close').addEventListener('click', close);
		box.querySelector('.lum-lightbox__next').addEventListener('click', function () { show(current + 1); });
		box.querySelector('.lum-lightbox__prev').addEventListener('click', function () { show(current - 1); });
		box.addEventListener('click', function (e) { if (e.target === box) { close(); } });
		document.addEventListener('keydown', function (e) {
			if (!box.classList.contains('is-open')) { return; }
			if (e.key === 'Escape') { close(); }
			if (e.key === 'ArrowRight') { show(current + 1); }
			if (e.key === 'ArrowLeft') { show(current - 1); }
			// Focus trap: keep Tab within the dialog while it's open.
			if (e.key === 'Tab') {
				var f = focusable();
				if (!f.length) { return; }
				var first = f[0];
				var last = f[f.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first.focus();
				}
			}
		});
	}

	/* ---------------------------------------------------------------
	 * Active nav highlight for current page
	 * ------------------------------------------------------------ */
	var path = window.location.pathname.replace(/\/+$/, '');
	document.querySelectorAll('.site-nav__list a').forEach(function (a) {
		var href = (a.getAttribute('href') || '').replace(/^https?:\/\/[^/]+/, '').replace(/\/+$/, '');
		if (href && href === path) {
			a.classList.add('is-current');
			a.setAttribute('aria-current', 'page'); // announce current page to AT
		}
	});

}());
