<?php
/**
 * Front page template — the photographer's landing experience.
 *
 * @package Luminance
 */

get_header();

$uploads = content_url( '/uploads/portfolio' );
?>

<section class="hero" style="--hero-img:url('<?php echo esc_url( $uploads . '/hero-ceremony.jpg' ); ?>')">
	<div class="hero__overlay"></div>
	<div class="hero__content">
		<p class="hero__eyebrow">Wedding &amp; Event Photography</p>
		<h1 class="hero__title">Light, held still.</h1>
		<p class="hero__lede">Documentary-style storytelling for weddings, celebrations and gatherings — unhurried, warm, and true to the day.</p>
		<div class="hero__actions">
			<a class="lum-btn" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>">View the portfolio</a>
			<a class="lum-btn lum-btn--ghost" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Enquire about your date</a>
		</div>
	</div>
	<span class="hero__scroll" aria-hidden="true">scroll</span>
</section>

<section class="intro">
	<div class="intro__inner">
		<p class="intro__kicker">— A studio for the in-between moments</p>
		<h2 class="intro__statement">The half-laugh before the vows. The hand found across a crowded room. I photograph the quiet gravity that holds a celebration together.</h2>
	</div>
</section>

<section class="featured">
	<div class="featured__head">
		<h2 class="section-title">Selected work</h2>
		<a class="section-link" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>">All galleries &rsaquo;</a>
	</div>

	<div class="masonry">
		<?php
		// Prefer the plugin's cached accessor (transient-backed) for the most-
		// visited page; fall back to a direct, tuned query if the plugin is off.
		if ( class_exists( 'Luminance_Scalability' ) ) {
			$featured_ids = Luminance_Scalability::get_featured_ids( 6 );
			$featured     = new WP_Query( array(
				'post_type'              => 'portfolio',
				'post__in'               => ! empty( $featured_ids ) ? $featured_ids : array( 0 ),
				'orderby'                => 'post__in',
				'posts_per_page'         => 6,
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
				'update_post_term_cache' => true,
			) );
		} else {
			$featured = new WP_Query( array(
				'post_type'              => 'portfolio',
				'posts_per_page'         => 6,
				'orderby'                => 'menu_order date',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
				'update_post_term_cache' => false,
			) );
		}

		if ( $featured->have_posts() ) :
			$lum_featured_i = 0;
			while ( $featured->have_posts() ) : $featured->the_post();
				$lum_featured_i++;
				// The first thumbnail is the LCP element on mobile, so load it
				// eagerly with high priority; lazy-load the rest.
				$lum_is_first = ( 1 === $lum_featured_i );
				$lum_img_attrs = array(
					'decoding' => 'async',
					'class'    => 'masonry__img',
					'sizes'    => '(max-width: 520px) 100vw, (max-width: 980px) 50vw, 33vw',
				);
				if ( $lum_is_first ) {
					$lum_img_attrs['loading']       = 'eager';
					$lum_img_attrs['fetchpriority']  = 'high';
				} else {
					$lum_img_attrs['loading'] = 'lazy';
				}
				?>
				<a class="masonry__item" href="<?php the_permalink(); ?>">
					<?php if ( has_post_thumbnail() ) : ?>
						<?php the_post_thumbnail( 'full', $lum_img_attrs ); ?>
					<?php endif; ?>
					<span class="masonry__caption">
						<span class="masonry__title"><?php the_title(); ?></span>
						<?php
						$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
						if ( $terms && ! is_wp_error( $terms ) ) {
							echo '<span class="masonry__cat">' . esc_html( $terms[0]->name ) . '</span>';
						}
						?>
					</span>
				</a>
				<?php
			endwhile;
			wp_reset_postdata();
		endif;
		?>
	</div>
</section>

<section class="testimonial">
	<div class="testimonial__inner">
		<p class="testimonial__quote">&ldquo;I saw the photos and felt like I was there &mdash; like I actually knew these people. Every frame takes me straight back to the day.&rdquo;</p>
		<p class="testimonial__cite">Caroline &amp; Matthew</p>
	</div>
</section>

<section class="services">
	<div class="services__inner">
		<h2 class="section-title section-title--center">How we work together</h2>
		<div class="services__grid">
			<article class="service">
				<span class="service__num">01</span>
				<h3 class="service__title">Weddings</h3>
				<p>Full-day documentary coverage, from the slow morning light to the last dance. Two photographers, a private online gallery, and heirloom prints.</p>
			</article>
			<article class="service">
				<span class="service__num">02</span>
				<h3 class="service__title">Events &amp; Galas</h3>
				<p>Corporate evenings, fundraisers and milestone celebrations covered with discretion and an editorial eye for atmosphere.</p>
			</article>
			<article class="service">
				<span class="service__num">03</span>
				<h3 class="service__title">Engagements</h3>
				<p>An unhurried session in a place that means something to you — the easiest way to feel at home in front of the camera before the big day.</p>
			</article>
		</div>
	</div>
</section>

<section class="cta" style="--cta-img:url('<?php echo esc_url( $uploads . '/portfolio-couple-golden.jpg' ); ?>')">
	<div class="cta__overlay"></div>
	<div class="cta__content">
		<h2 class="cta__title">Only a handful of dates each season.</h2>
		<p class="cta__text">If your day is coming, let's talk. I'd love to hear the story so far.</p>
		<a class="lum-btn lum-btn--light" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Check your date</a>
	</div>
</section>

<?php get_footer();
